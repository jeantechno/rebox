﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()
if ".preset-grid" not in t:
    t = t.rstrip() + "\n\n/* ---------------- 个性化预设 ---------------- */\n" + '''
.preset-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(118px, 1fr)); gap: 10px; }
.preset-card { display: flex; flex-direction: column; gap: 7px; padding: 8px; border-radius: 13px;
  border: 1px solid var(--line-soft); background: rgba(255,255,255,.05); cursor: pointer;
  transition: transform .18s var(--ease), border-color .2s, box-shadow .2s; text-align: left; }
.preset-card:hover { transform: translateY(-2px); border-color: rgba(94,234,212,.45); box-shadow: 0 8px 20px rgba(45,212,191,.18); }
.preset-card.on { border-color: rgba(94,234,212,.7); box-shadow: 0 0 0 1px rgba(94,234,212,.55), 0 8px 20px rgba(45,212,191,.25); }
.preset-card i { display: block; height: 44px; border-radius: 9px; }
.preset-card span { font-size: 12px; color: var(--text-2); }
'''
    io.open(P, "w", encoding="utf-8", newline="").write(t)
    print("css presets done")
else:
    print("css already done")
