﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "main.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '''def apply_icon(path):
    """通过 pythonnet 给窗口设置应用图标（任务栏 / 窗口标题栏）。"""
    if not path or not os.path.isfile(path):
        return
    try:
        import clr  # noqa: F401
        from System.Drawing import Icon
        w = webview.active_window()
        f = w.native
        f.Icon = Icon.FromFile(path)
        f.ShowIcon = True
    except Exception:
        pass'''
new = '''def apply_icon(path):
    """纯 Win32 设置窗口/任务栏图标（LoadImage + WM_SETICON），不依赖 pythonnet。"""
    if not path or not os.path.isfile(path):
        return
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, APP_TITLE)
        if not hwnd:
            return
        h_icon = user32.LoadImageW(None, path, 1, 0, 0, 0x10)  # IMAGE_ICON + LR_LOADFROMFILE
        if not h_icon:
            return
        user32.SendMessageW(hwnd, 0x0080, 0, h_icon)  # WM_SETICON, ICON_SMALL
        user32.SendMessageW(hwnd, 0x0080, 1, h_icon)  # WM_SETICON, ICON_BIG
    except Exception:
        pass'''
assert old in t, "apply_icon anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("main.py ok")
