# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "web", "js", "app.js")
t = io.open(P, "r", encoding="utf-8").read()

# 1) bindStatic 委托加 [data-preset]
old = '''    const ext = e.target.closest("[data-ext]");
    if (ext) { authorLink(ext.dataset.ext); return; }
  });'''
new = '''    const ext = e.target.closest("[data-ext]");
    if (ext) { authorLink(ext.dataset.ext); return; }
    const pre = e.target.closest("[data-preset]");
    if (pre) { applyPreset(pre.dataset.preset); return; }
  });'''
assert old in t, "delegate anchor missing"
t = t.replace(old, new, 1)

# 2) applyTheme 支持内置渐变预设
old = '''function applyTheme(imgOverride, blurOverride) {
  const aurora = $("#aurora");
  if (!aurora) return;
  const image = imgOverride || (state.theme && state.theme.image) || "";
  const blur = blurOverride != null ? blurOverride : ((state.theme && state.theme.blur) || 0);
  if (image) {
    const u = image.replace(/\\\\/g, "/").replace(/^([A-Za-z]):/, "file:///$1:");
    aurora.style.backgroundImage = 'url("' + u + '")';
    aurora.style.backgroundSize = "cover";
    aurora.style.backgroundPosition = "center";
  } else {
    aurora.style.backgroundImage = "";
  }
  aurora.style.filter = blur > 0 ? "blur(" + blur + "px) saturate(1.15)" : "";
}'''
new = '''const PRESETS = [
  { id: "aurora", name: "深空极光", blur: 6,
    grad: "radial-gradient(120% 130% at 15% 10%, #1c5a7a 0%, #0e2a4a 38%, #05080f 100%), radial-gradient(70% 55% at 82% 18%, rgba(45,212,191,.30), transparent 60%), radial-gradient(85% 65% at 55% 98%, rgba(56,189,248,.18), transparent 65%)" },
  { id: "mint", name: "液态薄荷", blur: 8,
    grad: "linear-gradient(140deg, #022c22 0%, #064e3b 45%, #0f766e 100%)" },
  { id: "ocean", name: "深海蓝", blur: 8,
    grad: "linear-gradient(140deg, #0b1730 0%, #12263f 52%, #1e3a5f 100%)" },
  { id: "amber", name: "鎏金琥珀", blur: 8,
    grad: "linear-gradient(140deg, #3d1507 0%, #7c2d12 48%, #b45309 100%)" },
];
function applyTheme(imgOverride, blurOverride, gradOverride) {
  const aurora = $("#aurora");
  if (!aurora) return;
  const image = imgOverride || (state.theme && state.theme.image) || "";
  const blur = blurOverride != null ? blurOverride : ((state.theme && state.theme.blur) || 0);
  const gid = gradOverride || (state.theme && state.theme.gradient) || "aurora";
  const grad = PRESETS.find((p) => p.id === gid);
  if (image) {
    const u = image.replace(/\\\\/g, "/").replace(/^([A-Za-z]):/, "file:///$1:");
    aurora.style.backgroundImage = 'url("' + u + '")';
    aurora.style.backgroundSize = "cover";
    aurora.style.backgroundPosition = "center";
  } else if (grad && grad.id !== "aurora") {
    aurora.style.backgroundImage = grad.grad;
  } else {
    aurora.style.backgroundImage = "";
  }
  aurora.style.filter = blur > 0 ? "blur(" + blur + "px) saturate(1.15)" : "";
}
function renderPresets() {
  const grid = $("#preset-grid");
  if (!grid) return;
  const cur = (state.theme && state.theme.gradient) || "aurora";
  grid.innerHTML = PRESETS.map((p) =>
    '<button class="preset-card' + (p.id === cur ? " on" : "") + '" data-preset="' + p.id + '">' +
    '<i style="background:' + p.grad + '"></i><span>' + p.name + "</span></button>").join("");
}
function applyPreset(id) {
  const p = PRESETS.find((x) => x.id === id) || PRESETS[0];
  state.theme.image = "";
  state.theme.gradient = p.id;
  if (p.blur != null) {
    state.theme.blur = p.blur;
    const bl = $("#theme-blur");
    if (bl) { bl.value = p.blur; $("#theme-blur-val").textContent = p.blur + "px"; }
  }
  const bg = $("#theme-bg");
  if (bg) bg.value = "";
  state.api.save_settings({ theme_image: "", theme_gradient: p.id, theme_blur: state.theme.blur });
  applyTheme();
  renderPresets();
  toast("已切换「" + p.name + "」风格", "ok");
}'''
assert old in t, "applyTheme anchor missing"
t = t.replace(old, new, 1)

# 3) boot 时渲染预设
old = '''  if (state.theme && state.theme.image) {
    $("#theme-bg").value = state.theme.image;
  }
  if (state.theme && state.theme.blur != null) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();'''
new = '''  if (state.theme && state.theme.image) {
    $("#theme-bg").value = state.theme.image;
  }
  if (state.theme && state.theme.blur != null) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();
  renderPresets();'''
assert old in t, "boot anchor missing"
t = t.replace(old, new, 1)

io.open(P, "w", encoding="utf-8", newline="").write(t)
print("js presets ok")

# CSS：预设卡片
P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()
old = ".slider-val { font-size: 11.5px; color: var(--text-3); }"
new = old + '''
.preset-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(118px, 1fr)); gap: 10px; }
.preset-card { display: flex; flex-direction: column; gap: 7px; padding: 8px; border-radius: 13px;
  border: 1px solid var(--line-soft); background: rgba(255,255,255,.05); cursor: pointer;
  transition: transform .18s var(--ease), border-color .2s, box-shadow .2s; text-align: left; }
.preset-card:hover { transform: translateY(-2px); border-color: rgba(94,234,212,.45); box-shadow: 0 8px 20px rgba(45,212,191,.18); }
.preset-card.on { border-color: rgba(94,234,212,.7); box-shadow: 0 0 0 1px rgba(94,234,212,.55), 0 8px 20px rgba(45,212,191,.25); }
.preset-card i { display: block; height: 44px; border-radius: 9px; }
.preset-card span { font-size: 12px; color: var(--text-2); }'''
assert old in t, "slider-val anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("css presets ok")
