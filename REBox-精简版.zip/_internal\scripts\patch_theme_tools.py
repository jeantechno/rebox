# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"

# ---------- 1) HTML：侧边栏加“个性化”，工具中心去外观，新建 theme 页 ----------
P = os.path.join(D, "web", "index.html")
t = io.open(P, "r", encoding="utf-8").read()

# 1a 侧边栏系统组加“个性化”
old = '''          <a class="nav-item" data-page="tools">
            <svg viewBox="0 0 24 24"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
            <span>工具中心</span></a>'''
new = '''          <a class="nav-item" data-page="tools">
            <svg viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M7 9h10M7 13h6"/></svg>
            <span>工具中心</span></a>
          <a class="nav-item" data-page="theme">
            <svg viewBox="0 0 24 24"><circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 1 0 10 10c0-1.8-1.5-3-3-3h-2.5a2.5 2.5 0 0 1-2-4A10 10 0 0 0 12 2z"/></svg>
            <span>个性化</span></a>'''
assert old in t, "sidebar anchor missing"
t = t.replace(old, new, 1)

# 1b 工具中心：移除外观设置块，改副标题
old = '''        <section class="page" data-page="tools">
          <div class="page-head"><h1>工具中心</h1><p>检测运行环境、下载或修复组件、自定义外观。</p></div>
          <div class="glass-card block">
            <h3 class="block-title">外观设置</h3>
            <div class="field">
              <label>背景图片（自定义壁纸）</label>
              <div class="path-row"><input class="input" id="theme-bg" placeholder="默认极光背景" readonly><button class="btn ghost sm" data-browse="file:png:theme-bg">选择图片</button><button class="btn ghost sm" id="theme-reset">恢复默认</button></div>
              <p class="hint">支持 .png / .jpg，立即生效并长期保留。</p>
            </div>
            <div class="field">
              <label>背景高斯模糊 <span class="slider-val" id="theme-blur-val">0px</span></label>
              <input type="range" class="slider" id="theme-blur" min="0" max="40" step="1" value="0">
              <p class="hint">模糊程度越大，背景越柔和，玻璃质感越明显。</p>
            </div>
          </div>
          <div class="glass-card block">'''
new = '''        <section class="page" data-page="tools">
          <div class="page-head"><h1>工具中心</h1><p>检测运行环境、下载或修复组件。</p></div>
          <div class="glass-card block">'''
assert old in t, "tools block anchor missing"
t = t.replace(old, new, 1)

# 1c 新建“个性化”页（放在 tools section 结束之后）
old = '''          <div class="author-card glass-card">
            <div class="author-avatar">解</div>
            <div class="author-info">
              <b>创作者：解域江安</b>
              <span>交流反馈欢迎加入 QQ 群或关注作者</span>
            </div>
            <div class="author-links">
              <button class="btn ghost sm" data-ext="qq">QQ 交流群 1124717353</button>
              <button class="btn ghost sm" data-ext="douyin">抖音：解域江安</button>
              <button class="btn ghost sm" data-ext="kuaishou">快手：解安</button>
            </div>
          </div>
        </section>

        <!-- ============ 关于 ============ -->'''
new = '''          <div class="author-card glass-card">
            <div class="author-avatar">解</div>
            <div class="author-info">
              <b>创作者：解域江安</b>
              <span>交流反馈欢迎加入 QQ 群或关注作者</span>
            </div>
            <div class="author-links">
              <button class="btn ghost sm" data-ext="qq">QQ 交流群 1124717353</button>
              <button class="btn ghost sm" data-ext="douyin">抖音：解域江安</button>
              <button class="btn ghost sm" data-ext="kuaishou">快手：解安</button>
            </div>
          </div>
        </section>

        <!-- ============ 个性化 ============ -->
        <section class="page" data-page="theme">
          <div class="page-head"><h1>个性化</h1><p>自定义背景壁纸与玻璃模糊质感，实时预览、长期保留。</p></div>
          <div class="glass-card block">
            <h3 class="block-title">外观设置</h3>
            <div class="field">
              <label>背景图片（自定义壁纸）</label>
              <div class="path-row"><input class="input" id="theme-bg" placeholder="默认极光背景" readonly><button class="btn ghost sm" data-browse="file:png:theme-bg">选择图片</button><button class="btn ghost sm" id="theme-reset">恢复默认</button></div>
              <p class="hint">支持 .png / .jpg，立即生效并长期保留。</p>
            </div>
            <div class="field">
              <label>背景高斯模糊 <span class="slider-val" id="theme-blur-val">0px</span></label>
              <input type="range" class="slider" id="theme-blur" min="0" max="40" step="1" value="0">
              <p class="hint">模糊程度越大，背景越柔和，玻璃质感越明显。</p>
            </div>
          </div>
          <div class="glass-card block">
            <h3 class="block-title">预设风格</h3>
            <div class="preset-grid" id="preset-grid"></div>
            <p class="hint">点击预设一键切换：深空极光（默认）、液态薄荷、深海蓝、鎏金琥珀。</p>
          </div>
        </section>

        <!-- ============ 关于 ============ -->'''
assert old in t, "author/about anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("html ok")

# ---------- 2) JS：renderTools 补 7-Zip / hap-sign-tool；预设风格渲染 ----------
P = os.path.join(D, "web", "js", "app.js")
t = io.open(P, "r", encoding="utf-8").read()

old = '''  $("#core-table").innerHTML =
    row("apktool", "APK 解包 / 回编译", t.apktool, btn("下载 / 修复", 'data-dl="apktool"')) +
    row("jadx", "DEX → Java 源码", t.jadx, btn("下载 / 修复", 'data-dl="jadx"')) +
    row("uber-apk-signer", "zipalign 对齐 + 签名", t.signer, btn("下载 / 修复", 'data-dl="signer"'));
'''
new = '''  $("#core-table").innerHTML =
    row("apktool", "APK 解包 / 回编译", t.apktool, btn("下载 / 修复", 'data-dl="apktool"')) +
    row("jadx", "DEX → Java 源码（APK / HAP 内 dex）", t.jadx, btn("下载 / 修复", 'data-dl="jadx"')) +
    row("uber-apk-signer", "zipalign 对齐 + 签名", t.signer, btn("下载 / 修复", 'data-dl="signer"')) +
    row("7-Zip", "deb / rpm / dmg / AppImage 解包（Linux / 苹果）", t["7zip"] || { ok: false, version: "", path: "" }, btn("下载 / 修复", 'data-dl="7zip"'));
'''
assert old in t, "core-table anchor missing"
t = t.replace(old, new, 1)

old = '''    row("dnSpyEx", ".NET 图形化反编译器", t.dnspy, btn("下载 dnSpy", 'data-dl="dnspy"', "ghost sm")) +
    row(".NET SDK / ilspycmd", "命令行导出 C#（未安装时自动改用 dnSpy）", t.dotnet, "");'''
new = '''    row("dnSpyEx", ".NET 图形化反编译器", t.dnspy, btn("下载 dnSpy", 'data-dl="dnspy"', "ghost sm")) +
    row(".NET SDK / ilspycmd", "命令行导出 C#（未安装时自动改用 dnSpy）", t.dotnet, "") +
    row("hap-sign-tool", "HAP 真机签名（可选：下载后放入 tools\\hapsigner.jar）", t.hapsigner || { ok: false, version: "", path: "" }, "");'''
assert old in t, "opt-table anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("js ok")

# ---------- 3) envdetect：加 hapsigner 检测 ----------
P = os.path.join(D, "app", "core", "envdetect.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '    tools["7zip"] = {"ok": _exists(z7), "version": "7-Zip" if _exists(z7) else "", "path": z7}'
new = (old + '\n'
       '    # hap-sign-tool（HAP 真机签名，可选）\n'
       '    hs = os.path.join(TOOLS_DIR, "hapsigner.jar")\n'
       '    tools["hapsigner"] = {"ok": _exists(hs), "version": "hap-sign-tool" if _exists(hs) else "", "path": hs}')
assert old in t, "envdetect 7zip anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("envdetect ok")

# ---------- 4) CSS：消除侧边栏悬停闪烁 ----------
P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()

old = ".sidebar { width: 218px; flex: 0 0 218px; display: flex; flex-direction: column; padding: 14px 12px; border-radius: var(--r-lg); overflow: hidden; }"
new = (".sidebar { width: 218px; flex: 0 0 218px; display: flex; flex-direction: column; padding: 14px 12px;"
       " border-radius: var(--r-lg); overflow: hidden; transform: translateZ(0); will-change: transform; }")
assert old in t, "sidebar anchor missing"
t = t.replace(old, new, 1)

old = '''.nav-item { position: relative; display: flex; align-items: center; gap: 11px; padding: 10px 13px;
  border-radius: 13px; color: var(--text-2); font-size: 13.5px; font-weight: 500; cursor: pointer;
  transition: color .22s var(--ease), background .22s, transform .18s var(--ease); }'''
new = '''.nav-item { position: relative; display: flex; align-items: center; gap: 11px; padding: 10px 13px;
  border-radius: 13px; color: var(--text-2); font-size: 13.5px; font-weight: 500; cursor: pointer;
  transition: color .22s var(--ease), transform .18s var(--ease); }
.nav-item::before { content: ""; position: absolute; inset: 0; border-radius: 13px;
  background: rgba(255,255,255,.07); opacity: 0; transition: opacity .22s; pointer-events: none; }
.nav-item:hover::before { opacity: 1; }
.nav-item.active::before { opacity: 0; }'''
assert old in t, "nav-item anchor missing"
t = t.replace(old, new, 1)

old = '''.nav-item:hover { color: #fff; background: rgba(255,255,255,.07); transform: translateX(2px); }'''
new = '''.nav-item:hover { color: #fff; transform: translateX(2px); }'''
assert old in t, "nav-item hover anchor missing"
t = t.replace(old, new, 1)

old = '''.nav-cursor { position: absolute; left: 0; right: 0; height: 40px; border-radius: 13px; z-index: 0;
  background: linear-gradient(135deg, #5eead4, #2dd4bf 60%, #38bdf8);
  box-shadow: 0 8px 22px rgba(45,212,191,.4), inset 0 1px 0 rgba(255,255,255,.5);
  transition: transform .38s var(--spring), height .25s;
  pointer-events: none; }'''
new = '''.nav-cursor { position: absolute; left: 0; right: 0; height: 40px; border-radius: 13px; z-index: 0;
  background: linear-gradient(135deg, #5eead4, #2dd4bf 60%, #38bdf8);
  box-shadow: 0 3px 10px rgba(45,212,191,.28), inset 0 1px 0 rgba(255,255,255,.45);
  transition: transform .38s var(--spring);
  pointer-events: none; }'''
assert old in t, "nav-cursor anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("css ok")
