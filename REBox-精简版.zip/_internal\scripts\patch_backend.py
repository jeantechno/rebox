# -*- coding: utf-8 -*-
"""一次性补丁：backend.py 注入 theme 字段 + 新平台方法。"""
import io, os

D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "backend.py")
t = io.open(P, "r", encoding="utf-8").read()

# 1) theme 注入 app_init
old = '            "workspace": settings.get("workspace", ""),\n            },'
new = ('            "workspace": settings.get("workspace", ""),\n'
       '            },\n'
       '            "theme": {\n'
       '                "image": settings.get("theme_image", ""),\n'
       '                "blur": int(settings.get("theme_blur", 0) or 0),\n'
       '            },')
if old in t:
    t = t.replace(old, new, 1)
    print("theme injected")
else:
    print("WARN theme anchor not found")

# 2) 新平台方法（追加到 job_cancel 之后）
extra = '''
    # ------------------------------------------------------------ 任务：HAP / Linux / 苹果
    def hap_decompile(self, p):
        t = manager.create("HAP 反编译")
        manager.run(t, lambda task: hap.decompile(
            task, p.get("hap"), p.get("outdir"),
            p.get("do_java", True), p.get("do_res", True)))
        return t.id

    def hap_build(self, p):
        t = manager.create("HAP 打包")
        manager.run(t, lambda task: hap.build(task, p.get("project"), p.get("outdir")))
        return t.id

    def linux_decompile(self, p):
        t = manager.create("Linux 软件包解包")
        manager.run(t, lambda task: linuxpkg.decompile(
            task, p.get("file"), p.get("outdir"), p.get("ghidra", False)))
        return t.id

    def linux_build(self, p):
        t = manager.create("Linux 打包")
        manager.run(t, lambda task: linuxpkg.build(task, p.get("project"), p.get("outdir")))
        return t.id

    def apple_decompile(self, p):
        t = manager.create("苹果软件包解包")
        manager.run(t, lambda task: apple.decompile(
            task, p.get("file"), p.get("outdir"), p.get("ghidra", False)))
        return t.id

    def apple_build(self, p):
        t = manager.create("苹果打包")
        manager.run(t, lambda task: apple.build(task, p.get("project"), p.get("outdir")))
        return t.id

    # ------------------------------------------------------------ 外观 / 外部跳转
    def theme_import(self, path):
        if not path or not os.path.isfile(path):
            return ""
        try:
            td = os.path.join(settings.workspace_dir(), "theme")
            os.makedirs(td, exist_ok=True)
            ext = os.path.splitext(path)[1].lower() or ".png"
            dst = os.path.join(td, "background" + ext)
            shutil.copy2(path, dst)
            return dst
        except Exception:
            return ""

    def open_external(self, url):
        if not url:
            return False
        try:
            os.startfile(url)
            return True
        except Exception:
            return False
'''
anchor = "    def job_cancel(self, job_id):\n        return manager.cancel(job_id)\n"
if anchor in t:
    t = t.replace(anchor, anchor + extra, 1)
    print("platform methods appended")
else:
    print("WARN methods anchor not found")

io.open(P, "w", encoding="utf-8", newline="").write(t)
print("backend.py written")
