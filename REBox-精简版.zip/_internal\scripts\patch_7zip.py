﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "core", "toolmgr.py")
t = io.open(P, "r", encoding="utf-8").read()

old = '''def install_7zip(task):
    """7-Zip 官方安装包静默安装到 tools\\\\7zip（NSIS /S /D=）。"""
    url = "https://www.7-zip.org/a/7z2201-x64.exe"
    exe_path = os.path.join(CACHE_DIR, "7z2201-x64.exe")
    os.makedirs(CACHE_DIR, exist_ok=True)
    dest = os.path.join(TOOLS_DIR, "7zip")
    if os.path.isfile(os.path.join(dest, "7z.exe")):
        task.log("7-Zip 已安装，跳过下载。", "ok")
        return True
    task.log("下载 7-Zip 官方安装包（约 2MB）……", "info")
    try:
        got = _download_one(url, exe_path, task, 2 * 1048576)
        if got < 1 * 1048576:
            raise RuntimeError("下载体积异常（%.1fMB）" % (got / 1048576))
    except Exception as e:
        raise RuntimeError("7-Zip 下载失败：%s" % e)
    os.makedirs(dest, exist_ok=True)
    task.log("静默安装到 %s……" % dest, "info")
    import subprocess
    p = subprocess.run([exe_path, "/S", "/D=" + dest],
                       creationflags=0x08000000, timeout=180)
    try:
        os.remove(exe_path)
    except Exception:
        pass
    if not os.path.isfile(os.path.join(dest, "7z.exe")):
        raise RuntimeError("7-Zip 安装失败：未找到 7z.exe（安装包可能被安全软件拦截）")
    task.log("7-Zip 安装完成：%s" % os.path.join(dest, "7z.exe"), "ok")
    return True'''

new = '''def install_7zip(task):
    """7-Zip 便携版：用官方 7zr.exe 解包安装包提取 7z.exe（免安装、免管理员权限，避免 WinError 740）。"""
    import subprocess
    dest = os.path.join(TOOLS_DIR, "7zip")
    if os.path.isfile(os.path.join(dest, "7z.exe")):
        task.log("7-Zip 已就绪，跳过下载。", "ok")
        return True
    os.makedirs(dest, exist_ok=True)
    zr = os.path.join(dest, "7zr.exe")
    exe_path = os.path.join(dest, "7z2201-x64.exe")
    task.log("下载 7-Zip 便携组件（官方 7zr.exe）……", "info")
    try:
        got = _download_one("https://www.7-zip.org/a/7zr.exe", zr, task, 512 * 1024)
        if got < 300 * 1024:
            raise RuntimeError("7zr.exe 下载体积异常")
        task.log("下载 7-Zip 安装包（解包用，约 2MB）……", "info")
        got2 = _download_one("https://www.7-zip.org/a/7z2201-x64.exe", exe_path, task, 2 * 1048576)
        if got2 < 1 * 1048576:
            raise RuntimeError("安装包下载体积异常")
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError("7-Zip 下载失败：%s" % e)
    task.log("解包便携版（免安装、免管理员权限）……", "info")
    try:
        p = subprocess.run([zr, "x", exe_path, "-o" + dest, "-y"],
                           creationflags=0x08000000, timeout=120,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if p.returncode != 0:
            raise RuntimeError("解包失败（exit %d）" % p.returncode)
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError("解包失败：%s" % e)
    finally:
        try:
            os.remove(exe_path)
        except Exception:
            pass
    if not os.path.isfile(os.path.join(dest, "7z.exe")):
        raise RuntimeError("7-Zip 解包失败：未找到 7z.exe")
    task.log("7-Zip 便携版就绪：%s" % os.path.join(dest, "7z.exe"), "ok")
    return True'''

assert old in t, "install_7zip anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("toolmgr patched")
