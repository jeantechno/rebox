﻿# -*- coding: utf-8 -*-
"""生成科幻风格 REBox 图标：霓虹六边形 + 逆向环 + 电路装饰。"""
import os, math
from PIL import Image, ImageDraw, ImageFilter

D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
OUT_PNG = os.path.join(D, "web", "img", "icon_1024.png")
OUT_ICO = os.path.join(D, "REBox.ico")
os.makedirs(os.path.join(D, "web", "img"), exist_ok=True)

S = 1024
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
bg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
dbg = ImageDraw.Draw(bg)

# 圆角方块底 + 垂直渐变
R = 190
mask = Image.new("L", (S, S), 0)
dm = ImageDraw.Draw(mask)
dm.rounded_rectangle([16, 16, S - 16, S - 16], radius=R, fill=255)
top = (10, 18, 40, 255)
bot = (5, 8, 15, 255)
grad = Image.new("RGBA", (S, S))
dg = ImageDraw.Draw(grad)
for y in range(S):
    k = y / S
    c = tuple(int(top[i] + (bot[i] - top[i]) * k) for i in range(3))
    dg.line([(0, y), (S, y)], fill=c + (255,))
bg = Image.composite(grad, bg, mask)

# 霓虹层（模糊发光）
glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
dg2 = ImageDraw.Draw(glow)
C_TEAL = (94, 234, 212, 255)
C_BLUE = (56, 189, 248, 255)
C_DARK = (8, 30, 45, 255)

cx, cy = S // 2, S // 2
def hex_pts(r, rot=0):
    pts = []
    for i in range(6):
        a = math.radians(60 * i - 90 + rot)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts

# 1) 六边形外框（双层 + 发光）
hex_big = hex_pts(350, rot=30)
dg2.polygon(hex_big, outline=(45, 200, 200, 130), width=10)
hex_mid = hex_pts(338, rot=30)
dg2.polygon(hex_mid, outline=(94, 234, 212, 235), width=6)
hex_small = hex_pts(326, rot=30)
dg2.polygon(hex_small, outline=(170, 245, 230, 160), width=3)

# 2) 内圆环（双环 + 发光）
bbox = [cx - 250, cy - 250, cx + 250, cy + 250]
dg2.ellipse(bbox, outline=(94, 234, 212, 220), width=16)
bbox2 = [cx - 265, cy - 265, cx + 265, cy + 265]
dg2.ellipse(bbox2, outline=(56, 189, 248, 120), width=5)
bbox3 = [cx - 180, cy - 180, cx + 180, cy + 180]
dg2.ellipse(bbox3, outline=(56, 189, 248, 90), width=4)

# 3) 中心菱形/电路芯片
diamond = [(cx, cy - 130), (cx + 130, cy), (cx, cy + 130), (cx - 130, cy)]
dg2.polygon(diamond, outline=(160, 245, 230, 210), width=8)
dg2.line([(cx, cy - 130), (cx, cy + 130)], fill=(94, 234, 212, 150), width=5)
dg2.line([(cx - 130, cy), (cx + 130, cy)], fill=(94, 234, 212, 150), width=5)

# 4) 逆向箭头（环上的 ⇄ 断口 + 三角）
def arrow(angle_deg, outward, size=46):
    a = math.radians(angle_deg)
    # 环半径上的点
    px, py = cx + 250 * math.cos(a), cy + 250 * math.sin(a)
    if outward:
        dx, dy = math.cos(a), math.sin(a)
    else:
        dx, dy = -math.cos(a), -math.sin(a)
    tip = (px + dx * size * 1.6, py + dy * size * 1.6)
    b1 = (px - dx * size * 0.5 + dy * size * 0.8, py - dy * size * 0.5 - dx * size * 0.8)
    b2 = (px - dx * size * 0.5 - dy * size * 0.8, py - dy * size * 0.5 + dx * size * 0.8)
    return [tip, b1, b2]

for ang in (0, 90, 180, 270):
    dg2.polygon(arrow(ang, True), fill=C_TEAL)
# 环上缺口：擦掉两段弧（用背景色圆点盖）→ 不擦，直接在 4 个方向做箭头=输入输出

# 5) 角落电路装饰
for (ax, ay) in [(130, 150), (S - 130, 150), (130, S - 150), (S - 130, S - 150)]:
    dg2.ellipse([ax - 14, ay - 14, ax + 14, ay + 14], fill=C_BLUE)
    dg2.line([(ax, ay + 14), (ax, ay + 55)], fill=(56, 189, 248, 160), width=6)
    dg2.line([(ax, ay - 55), (ax, ay - 14)], fill=(56, 189, 248, 160), width=6)

# 发光：模糊霓虹层
glow_blur = glow.filter(ImageFilter.GaussianBlur(36))
# 高光核心（细线清晰版）
core = Image.new("RGBA", (S, S), (0, 0, 0, 0))
dc = ImageDraw.Draw(core)
dc.polygon(hex_pts(326, rot=30), outline=(200, 255, 245, 255), width=4)
dc.ellipse(bbox, outline=(200, 250, 240, 255), width=10)
dc.polygon(diamond, outline=(220, 255, 248, 255), width=6)
for ang in (0, 90, 180, 270):
    dc.polygon(arrow(ang, True, 40), fill=(220, 255, 248, 255))

# 左上高光斑
sp = Image.new("RGBA", (S, S), (0, 0, 0, 0))
dsp = ImageDraw.Draw(sp)
dsp.ellipse([180, 130, 420, 260], fill=(150, 240, 230, 40))

out = Image.alpha_composite(bg, glow_blur)
out = Image.alpha_composite(out, core)
out = Image.alpha_composite(out, sp)
out = Image.alpha_composite(out, Image.composite(Image.new("RGBA", (S, S), (0, 0, 0, 0)), img, mask))
out = Image.alpha_composite(out, Image.new("RGBA", (S, S), (0, 0, 0, 0)).convert("RGBA"))
# 圆角裁剪
out = Image.composite(out, Image.new("RGBA", (S, S), (0, 0, 0, 0)), mask)
out.save(OUT_PNG)

# 多尺寸 ICO
ico_sizes = [(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)]
imgs = [out.resize((s, s), Image.LANCZOS) for s, _ in ico_sizes]
imgs[0].save(OUT_ICO, format="ICO", sizes=ico_sizes, append_images=imgs[1:])
print("PNG:", OUT_PNG)
print("ICO:", OUT_ICO, os.path.getsize(OUT_ICO), "bytes")
