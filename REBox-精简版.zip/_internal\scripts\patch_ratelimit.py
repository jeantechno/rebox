﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"

# ---------- toolmgr：latest_asset 缓存 + 友好报错 ----------
P = os.path.join(D, "app", "core", "toolmgr.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '''def latest_asset(repo, pattern):
    """返回 (tag, filename, url, size_mb)。"""
    import re
    api = "https://api.github.com/repos/%s/releases/latest" % repo
    req = urllib.request.Request(api, headers=UA)
    with urllib.request.urlopen(req, timeout=25) as r:
        rel = json.loads(r.read().decode("utf-8"))
    for a in rel.get("assets", []):
        if re.match(pattern, a["name"]):
            return rel["tag_name"], a["name"], a["browser_download_url"], round(a["size"] / 1048576, 1)
    raise RuntimeError("在 %s 的最新发布中未找到匹配 %s 的文件" % (repo, pattern))'''
new = '''_LA_CACHE = os.path.join(CACHE_DIR, "latest_assets.json")
_LA_TTL = 6 * 3600  # 版本信息缓存 6 小时，避免触发 GitHub API 限流


def latest_asset(repo, pattern):
    """返回 (tag, filename, url, size_mb)。带本地缓存，API 限流（403）时回退缓存并给出友好提示。"""
    import re
    key = repo + "|" + pattern
    cache = {}
    try:
        if os.path.isfile(_LA_CACHE):
            with io.open(_LA_CACHE, "r", encoding="utf-8") as f:
                cache = json.load(f)
    except Exception:
        cache = {}
    hit = cache.get(key)
    if hit and time.time() - hit.get("ts", 0) < _LA_TTL:
        return hit["tag"], hit["fname"], hit["url"], hit["size_mb"]
    try:
        api = "https://api.github.com/repos/%s/releases/latest" % repo
        req = urllib.request.Request(api, headers=UA)
        with urllib.request.urlopen(req, timeout=25) as r:
            rel = json.loads(r.read().decode("utf-8"))
        for a in rel.get("assets", []):
            if re.match(pattern, a["name"]):
                rec = {"ts": time.time(), "tag": rel["tag_name"], "fname": a["name"],
                       "url": a["browser_download_url"], "size_mb": round(a["size"] / 1048576, 1)}
                cache[key] = rec
                try:
                    os.makedirs(CACHE_DIR, exist_ok=True)
                    with io.open(_LA_CACHE, "w", encoding="utf-8") as f:
                        json.dump(cache, f, ensure_ascii=False)
                except Exception:
                    pass
                return rec["tag"], rec["fname"], rec["url"], rec["size_mb"]
        raise RuntimeError("在 %s 的最新发布中未找到匹配 %s 的文件" % (repo, pattern))
    except Exception as e:
        if hit:
            return hit["tag"], hit["fname"], hit["url"], hit["size_mb"]
        if isinstance(e, urllib.error.HTTPError) and e.code == 403:
            raise RuntimeError("GitHub API 限流（403）——稍等几分钟再点一次即可，或按工具说明手动获取后放入对应目录。")
        raise RuntimeError("查询 %s 最新版本失败：%s" % (repo, str(e)[:140]))'''
assert old in t, "latest_asset anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("toolmgr ok")

# ---------- task：错误只显示简短信息，不打印完整堆栈 ----------
P = os.path.join(D, "app", "core", "task.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '''            except Exception as e:
                import traceback
                t.log(traceback.format_exc(), "error")
                t.finish(False, "出错：%s" % e)'''
new = '''            except Exception as e:
                t.log("任务失败：%s" % e, "error")
                t.finish(False, "出错：%s" % e)'''
assert old in t, "task error anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("task ok")
