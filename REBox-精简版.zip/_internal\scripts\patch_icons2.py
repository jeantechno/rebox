﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "web", "index.html")
t = io.open(P, "r", encoding="utf-8").read()

# ============ 侧边栏图标（10 个） ============
NAV = [
# APK 反编译：安卓机器人
('''          <a class="nav-item" data-page="apk-dec">
            <svg viewBox="0 0 24 24"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>''',
'''          <a class="nav-item" data-page="apk-dec">
            <svg viewBox="0 0 24 24"><path d="M8 9.6V8.2a4 4 0 0 1 8 0v1.4"/><path d="M8 9.6h8v5.8a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2z"/><path d="M9.5 6.1V4.4M14.5 6.1V4.4"/><path d="M10.7 12.3h.01M13.3 12.3h.01"/><path d="M6.5 10v4M17.5 10v4"/><path d="M10 15.8v2.7M14 15.8v2.7"/></svg>'''),
# APK 回编译：安卓+扳手
('''          <a class="nav-item" data-page="apk-build">
            <svg viewBox="0 0 24 24"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/><path d="M17 14v5M14.5 16.5h5"/></svg>''',
'''          <a class="nav-item" data-page="apk-build">
            <svg viewBox="0 0 24 24"><path d="M6.5 9.6V8.2a3.5 3.5 0 0 1 7 0v1.4"/><path d="M6.5 9.6h7v5.2a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2z"/><path d="M8 6.3V4.6M12.5 6.3V4.6"/><path d="M9.2 12.2h.01M11.2 12.2h.01"/><path d="M5 10.2v3.8M15 10.2v3.8"/><path d="M8.5 15.2v2.4M12 15.2v2.4"/><path d="M15.8 5.6a2.8 2.8 0 0 1 4 2.5 2.8 2.8 0 0 1-1.2 2.3L14.4 14.4a1.9 1.9 0 0 1-2.7-2.7l4.1-4.1a2.8 2.8 0 0 1 0-2z"/></svg>'''),
# EXE 反编译：Windows 四窗格
('''          <a class="nav-item" data-page="exe-dec">
            <svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"/></svg>''',
'''          <a class="nav-item" data-page="exe-dec">
            <svg viewBox="0 0 24 24"><path d="M3.5 5.2 9.6 4.5v7.1H3.5z"/><path d="M3.5 17.5l6.1.7v-6.2H3.5z"/><path d="m10.4 11.6 10.1 1.2V3.9L10.4 5z"/><path d="m10.4 18.5 10.1 1.2v-6.9l-10.1 1.1z"/></svg>'''),
# EXE 打包：入盒
('''          <a class="nav-item" data-page="exe-build">
            <svg viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>''',
'''          <a class="nav-item" data-page="exe-build">
            <svg viewBox="0 0 24 24"><path d="M12 3.5v8"/><path d="m8.6 8.1 3.4 3.4 3.4-3.4"/><path d="M4 16.5v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/><path d="M3.5 16.5 3 11.2l2.5-1.9M20.5 16.5 21 11.2l-2.5-1.9M5.5 9.3h13"/></svg>'''),
# HAP 反编译：鸿蒙花
('''          <a class="nav-item" data-page="hap-dec">
            <svg viewBox="0 0 24 24"><path d="M12 2 4 6v6c0 5 3.4 9.4 8 10 4.6-.6 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/></svg>''',
'''          <a class="nav-item" data-page="hap-dec">
            <svg viewBox="0 0 24 24"><path d="M12 12c0-4.6 2.3-7.5 5.2-8.6"/><path d="M12 12c0 4.6-2.3 7.5-5.2 8.6"/><path d="M12 12c4.4-1.7 7.2-.8 8.8 1.7"/><path d="M12 12c-4.4 1.7-7.2.8-8.8-1.7"/><circle cx="12" cy="12" r="1.9"/></svg>'''),
# HAP 打包：鸿蒙花+扳手
('''          <a class="nav-item" data-page="hap-build">
            <svg viewBox="0 0 24 24"><path d="M12 2 4 6v6c0 5 3.4 9.4 8 10 4.6-.6 8-5 8-10V6z"/><path d="M8 12h8M12 8v8"/></svg>''',
'''          <a class="nav-item" data-page="hap-build">
            <svg viewBox="0 0 24 24"><path d="M12 12c0-4.6 2.3-7.5 5.2-8.6"/><path d="M12 12c0 4.6-2.3 7.5-5.2 8.6"/><path d="M12 12c4.4-1.7 7.2-.8 8.8 1.7"/><path d="M12 12c-4.4 1.7-7.2.8-8.8-1.7"/><circle cx="12" cy="12" r="1.9"/><path d="M15.8 5.6a2.8 2.8 0 0 1 4 2.5 2.8 2.8 0 0 1-1.2 2.3L14.4 14.4a1.9 1.9 0 0 1-2.7-2.7l4.1-4.1a2.8 2.8 0 0 1 0-2z"/></svg>'''),
# Linux 反编译：企鹅
('''          <a class="nav-item" data-page="lnx-dec">
            <svg viewBox="0 0 24 24"><path d="M3 7h18M8 7V3h8v4M6 7v14h12V7"/><path d="M9 11h.01M15 11h.01"/></svg>''',
'''          <a class="nav-item" data-page="lnx-dec">
            <svg viewBox="0 0 24 24"><path d="M12 3.8c3.6 0 5.6 3.2 5.6 7.2 0 2-.4 3.6-1.3 5.1l-1 3.1h-6.6l-1-3.1c-.9-1.5-1.3-3.1-1.3-5.1 0-4 2-7.2 5.6-7.2z"/><path d="M9.8 9.6h.01M14.2 9.6h.01"/><path d="m12 11 1.5 1.3-1.5 1.4-1.5-1.4z"/><path d="M6.4 12.3c-1.8 1-2.2 3-1.2 4.4l1 1.5M17.6 12.3c1.8 1 2.2 3 1.2 4.4l-1 1.5"/><path d="M9.5 13.7c.6 2.3 1.4 4 2.5 4s1.9-1.7 2.5-4"/><path d="M10.3 19.4h3.4"/></svg>'''),
# Linux 打包：终端
('''          <a class="nav-item" data-page="lnx-build">
            <svg viewBox="0 0 24 24"><path d="M3 7h18M8 7V3h8v4M6 7v14h12V7"/><path d="M12 11v6M9.5 14.5 12 17l2.5-2.5"/></svg>''',
'''          <a class="nav-item" data-page="lnx-build">
            <svg viewBox="0 0 24 24"><path d="M3.5 5h17v14h-17z"/><path d="m6.8 9.3 3 3-3 3"/><path d="M12.5 15.3h4.8"/></svg>'''),
# 苹果反编译：带咬痕苹果
('''          <a class="nav-item" data-page="mac-dec">
            <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 0 1 10 10c0 4-3 7-7 9-1.5-2-1-3-1-3s-1.5-1-2 1c-1 .5-3 .5-4 0 0 0 0 2-1 3-4-2-7-5-7-9A10 10 0 0 1 12 2z"/><circle cx="9" cy="10" r="1"/><circle cx="15" cy="10" r="1"/></svg>''',
'''          <a class="nav-item" data-page="mac-dec">
            <svg viewBox="0 0 24 24"><path d="M12 4.4c-1.7-1.3-4.1-1.1-5.2 1.1-1.3 2.5-1 6.5 1.6 9.8 1.5 1.9 2.8 4 3.6 5.6.8-1.6 2.1-3.7 3.6-5.6 2.6-3.3 2.9-7.3 1.6-9.8-1.1-2.2-3.5-2.4-5.2-1.1z"/><path d="M17.5 8.5a2.3 2.3 0 0 0-1.6-2.2"/><path d="M14.6 3c.6-1.3 2.1-1.9 3.4-1.4"/></svg>'''),
# 苹果打包：带咬痕苹果+扳手
('''          <a class="nav-item" data-page="mac-build">
            <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 0 1 10 10c0 4-3 7-7 9-1.5-2-1-3-1-3s-1.5-1-2 1c-1 .5-3 .5-4 0 0 0 0 2-1 3-4-2-7-5-7-9A10 10 0 0 1 12 2z"/><path d="M12 7v6M9 10h6"/></svg>''',
'''          <a class="nav-item" data-page="mac-build">
            <svg viewBox="0 0 24 24"><path d="M10.6 3.9c-1.4-1.1-3.4-.9-4.3.9-1.1 2.1-.8 5.4 1.3 8.2 1.2 1.6 2.3 3.3 3 4.6.7-1.3 1.8-3 3-4.6 2.1-2.8 2.4-6.1 1.3-8.2-.9-1.8-2.9-2-4.3-.9z"/><path d="M14.8 4.4c.5-1.1 1.8-1.6 2.8-1.2"/><path d="M15.8 5.6a2.8 2.8 0 0 1 4 2.5 2.8 2.8 0 0 1-1.2 2.3L14.4 14.4a1.9 1.9 0 0 1-2.7-2.7l4.1-4.1a2.8 2.8 0 0 1 0-2z"/></svg>'''),
]
for old, new in NAV:
    assert old in t, "nav anchor missing: " + old[:60]
    t = t.replace(old, new, 1)
print("nav icons ok:", len(NAV))

# ============ 卡片：Linux->企鹅，苹果->咬痕 ============
old = '''<div class="feat-ico c-cyan"><svg viewBox="0 0 24 24"><path d="M3.5 5h17v14h-17z"/><path d="m6.8 9.3 3 3-3 3"/><path d="M12.5 15.3h4.8"/></svg></div>
              <h3>Linux 软件包</h3>'''
new = '''<div class="feat-ico c-green"><svg viewBox="0 0 24 24"><path d="M12 3.8c3.6 0 5.6 3.2 5.6 7.2 0 2-.4 3.6-1.3 5.1l-1 3.1h-6.6l-1-3.1c-.9-1.5-1.3-3.1-1.3-5.1 0-4 2-7.2 5.6-7.2z"/><path d="M9.8 9.6h.01M14.2 9.6h.01"/><path d="m12 11 1.5 1.3-1.5 1.4-1.5-1.4z"/><path d="M6.4 12.3c-1.8 1-2.2 3-1.2 4.4l1 1.5M17.6 12.3c1.8 1 2.2 3 1.2 4.4l-1 1.5"/><path d="M9.5 13.7c.6 2.3 1.4 4 2.5 4s1.9-1.7 2.5-4"/><path d="M10.3 19.4h3.4"/></svg></div>
              <h3>Linux 软件包</h3>'''
assert old in t, "card linux anchor missing"
t = t.replace(old, new, 1)

old = '''<div class="feat-ico c-rose"><svg viewBox="0 0 24 24"><path d="M12 4.4c-1.7-1.3-4.1-1.1-5.2 1.1-1.3 2.5-1 6.5 1.6 9.8 1.5 1.9 2.8 4 3.6 5.6.8-1.6 2.1-3.7 3.6-5.6 2.6-3.3 2.9-7.3 1.6-9.8-1.1-2.2-3.5-2.4-5.2-1.1z"/><path d="M14.6 3c.6-1.3 2.1-1.9 3.4-1.4"/></svg></div>
              <h3>苹果软件包</h3>'''
new = '''<div class="feat-ico c-rose"><svg viewBox="0 0 24 24"><path d="M12 4.4c-1.7-1.3-4.1-1.1-5.2 1.1-1.3 2.5-1 6.5 1.6 9.8 1.5 1.9 2.8 4 3.6 5.6.8-1.6 2.1-3.7 3.6-5.6 2.6-3.3 2.9-7.3 1.6-9.8-1.1-2.2-3.5-2.4-5.2-1.1z"/><path d="M17.5 8.5a2.3 2.3 0 0 0-1.6-2.2"/><path d="M14.6 3c.6-1.3 2.1-1.9 3.4-1.4"/></svg></div>
              <h3>苹果软件包</h3>'''
assert old in t, "card mac anchor missing"
t = t.replace(old, new, 1)

# ============ 卡片配色：EXE反编译->紫，HAP->蓝，Linux->绿 ============
t = t.replace('''<div class="feat-ico c-rose"><svg viewBox="0 0 24 24"><path d="M3.5 5.2 9.6 4.5v7.1H3.5z"/><path d="M3.5 17.5l6.1.7v-6.2H3.5z"/><path d="m10.4 11.6 10.1 1.2V3.9L10.4 5z"/><path d="m10.4 18.5 10.1 1.2v-6.9l-10.1 1.1z"/><circle cx="18.2" cy="15.8" r="2.3"/><path d="M19.9 17.5 21.6 19.2"/></svg></div>''',
'''<div class="feat-ico c-violet"><svg viewBox="0 0 24 24"><path d="M3.5 5.2 9.6 4.5v7.1H3.5z"/><path d="M3.5 17.5l6.1.7v-6.2H3.5z"/><path d="m10.4 11.6 10.1 1.2V3.9L10.4 5z"/><path d="m10.4 18.5 10.1 1.2v-6.9l-10.1 1.1z"/><circle cx="18.2" cy="15.8" r="2.3"/><path d="M19.9 17.5 21.6 19.2"/></svg></div>''', 1)
t = t.replace('''<div class="feat-ico c-teal"><svg viewBox="0 0 24 24"><path d="M12 12c0-4.6 2.3-7.5 5.2-8.6"/><path d="M12 12c0 4.6-2.3 7.5-5.2 8.6"/><path d="M12 12c4.4-1.7 7.2-.8 8.8 1.7"/><path d="M12 12c-4.4 1.7-7.2.8-8.8-1.7"/><circle cx="12" cy="12" r="1.9"/></svg></div>''',
'''<div class="feat-ico c-blue"><svg viewBox="0 0 24 24"><path d="M12 12c0-4.6 2.3-7.5 5.2-8.6"/><path d="M12 12c0 4.6-2.3 7.5-5.2 8.6"/><path d="M12 12c4.4-1.7 7.2-.8 8.8 1.7"/><path d="M12 12c-4.4 1.7-7.2.8-8.8-1.7"/><circle cx="12" cy="12" r="1.9"/></svg></div>''', 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("cards ok")

# ============ CSS：新增 3 个配色类 ============
P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()
old = ".c-rose { color: #3a0a12; background: linear-gradient(135deg, #fda4af, #fb7185); box-shadow: 0 10px 24px rgba(251,113,133,.32); }"
new = old + '''
.c-violet { color: #241040; background: linear-gradient(135deg, #c4b5fd, #8b5cf6); box-shadow: 0 10px 24px rgba(139,92,246,.35); }
.c-blue { color: #062040; background: linear-gradient(135deg, #93c5fd, #60a5fa); box-shadow: 0 10px 24px rgba(96,165,250,.35); }
.c-green { color: #04240f; background: linear-gradient(135deg, #86efac, #4ade80); box-shadow: 0 10px 24px rgba(74,222,128,.35); }'''
assert old in t, "css color anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("css colors ok")
