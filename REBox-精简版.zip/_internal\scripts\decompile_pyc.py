# -*- coding: utf-8 -*-
"""批量把目录内所有 .pyc 反编译为 .py（decompyle3，支持 Python 3.7-3.9）。
用法: python decompile_pyc.py <pyc根目录> <输出目录>
"""
import os
import sys


def main():
    if len(sys.argv) < 3:
        print("usage: decompile_pyc.py <src> <out>")
        return 2
    src, out = sys.argv[1], sys.argv[2]
    from decompyle3.main import decompile_file

    ok = 0
    fail = 0
    failed = []
    for root, _, files in os.walk(src):
        for fn in files:
            if not fn.endswith(".pyc"):
                continue
            p = os.path.join(root, fn)
            rel = os.path.relpath(p, src)[:-4] + ".py"
            op = os.path.join(out, rel)
            try:
                os.makedirs(os.path.dirname(op) or ".", exist_ok=True)
                with open(op, "w", encoding="utf-8") as fo:
                    decompile_file(p, fo)
                ok += 1
                if ok % 50 == 0:
                    print("decompiled %d ..." % ok)
            except Exception as e:
                fail += 1
                failed.append("%s\t%s" % (rel, e))
    print("DECOMPYLE_OK=%d FAIL=%d" % (ok, fail))
    if failed:
        with open(os.path.join(out, "_failed_list.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(failed))
    return 0


if __name__ == "__main__":
    sys.exit(main())
