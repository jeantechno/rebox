﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "core", "envdetect.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '''    dn = shutil.which("dotnet")
    info = {"ok": False, "version": "", "path": dn or ""}
    if dn:
        code, out = _run([dn, "--version"], timeout=20)
        if code == 0 and out.strip():
            info.update(ok=True, version=out.strip().splitlines()[0])
    tools["dotnet"] = info'''
new = '''    dn = shutil.which("dotnet")
    info = {"ok": False, "version": "", "path": dn or ""}
    if dn:
        info.update(ok=True)  # 找到 SDK 即可用；版本检测失败不影响反编译（自动回退 dnSpy）
        try:
            code, out = _run([dn, "--version"], timeout=40)
            if code == 0 and out.strip():
                info["version"] = out.strip().splitlines()[0]
        except Exception:
            pass
    tools["dotnet"] = info'''
assert old in t, "dotnet anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("envdetect ok")
