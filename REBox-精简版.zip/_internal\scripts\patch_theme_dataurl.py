﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"

# ---------- 后端：theme_image_data 返回 data URL ----------
P = os.path.join(D, "app", "backend.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '''    def open_external(self, url):
        if not url:'''
new = '''    def theme_image_data(self):
        """读取当前背景图片为 base64 data URL（WebView2 禁止 file:// 子资源，必须内嵌）。"""
        p = settings.get("theme_image", "")
        if not p or not os.path.isfile(p):
            return ""
        try:
            with open(p, "rb") as f:
                b = f.read()
            ext = os.path.splitext(p)[1].lower()
            mime = "image/jpeg" if ext in (".jpg", ".jpeg") else "image/png"
            import base64
            return "data:%s;base64,%s" % (mime, base64.b64encode(b).decode("ascii"))
        except Exception:
            return ""

    def open_external(self, url):
        if not url:'''
assert old in t, "backend open_external anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("backend ok")

# ---------- 前端 ----------
P = os.path.join(D, "web", "js", "app.js")
t = io.open(P, "r", encoding="utf-8").read()

# applyTheme：仅接受 data URL 或渐变
old = '''  if (image) {
    const u = image.replace(/\\\\/g, "/").replace(/^([A-Za-z]):/, "file:///$1:");
    aurora.style.backgroundImage = 'url("' + u + '")';
    aurora.style.backgroundSize = "cover";
    aurora.style.backgroundPosition = "center";
  } else if (grad && grad.id !== "aurora") {'''
new = '''  if (image && image.indexOf("data:") === 0) {
    aurora.style.backgroundImage = 'url("' + image + '")';
    aurora.style.backgroundSize = "cover";
    aurora.style.backgroundPosition = "center";
  } else if (grad && grad.id !== "aurora") {'''
assert old in t, "applyTheme image branch missing"
t = t.replace(old, new, 1)

# 选图 change：theme_import 后取 data URL 存内存
old = '''    const p = await state.api.theme_import(v);
    if (p) {
      state.theme.image = p;
      await state.api.save_settings({ theme_image: p });
      applyTheme();
      toast("背景已更新，立即生效", "ok");
    } else {
      toast("背景导入失败", "error");
    }'''
new = '''    const p = await state.api.theme_import(v);
    if (p) {
      const data = await state.api.theme_image_data();
      state.theme.image = data || "";
      await state.api.save_settings({ theme_image: p });
      applyTheme();
      toast("背景已更新，立即生效", "ok");
    } else {
      toast("背景导入失败", "error");
    }'''
assert old in t, "theme change branch missing"
t = t.replace(old, new, 1)

# boot：路径转 data URL
old = '''  state.theme = Object.assign({ image: "", blur: 0, gradient: "aurora" }, info.theme || {});
  if (state.theme.image) $("#theme-bg").value = state.theme.image;
  if (state.theme.blur) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();
  renderPresets();'''
new = '''  state.theme = Object.assign({ image: "", blur: 0, gradient: "aurora" }, info.theme || {});
  if (state.theme.image) {
    $("#theme-bg").value = state.theme.image;
    const data = await state.api.theme_image_data();
    if (data) state.theme.image = data;
  }
  if (state.theme.blur) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();
  renderPresets();'''
assert old in t, "boot theme block missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("js ok")
