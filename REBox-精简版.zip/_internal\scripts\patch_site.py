﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
SITE = "https://xn--cjs28fo1tr01a.rth1.xyz/"

# ---------- HTML：主页 + 关于 作者卡各加“官网”按钮 ----------
P = os.path.join(D, "web", "index.html")
t = io.open(P, "r", encoding="utf-8").read()
cnt = 0
old = '''              <button class="btn ghost sm" data-ext="douyin">抖音：解域江安</button>
              <button class="btn ghost sm" data-ext="kuaishou">快手：解安</button>'''
new = '''              <button class="btn ghost sm" data-ext="douyin">抖音：解域江安</button>
              <button class="btn ghost sm" data-ext="kuaishou">快手：解安</button>
              <button class="btn ghost sm" data-ext="web">官网</button>'''
n = t.count(old)
assert n >= 1, "author links anchor missing"
t = t.replace(old, new)
cnt += n

old2 = '''                <button class="btn ghost sm" data-ext="douyin">抖音主页</button>
                <button class="btn ghost sm" data-ext="kuaishou">快手主页</button>'''
new2 = '''                <button class="btn ghost sm" data-ext="douyin">抖音主页</button>
                <button class="btn ghost sm" data-ext="kuaishou">快手主页</button>
                <button class="btn ghost sm" data-ext="web">官网</button>'''
n2 = t.count(old2)
assert n2 >= 1, "about links anchor missing"
t = t.replace(old2, new2)
cnt += n2
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("html patched:", cnt, "spots")

# ---------- JS：authorLink 加 web 分支 ----------
P = os.path.join(D, "web", "js", "app.js")
t = io.open(P, "r", encoding="utf-8").read()
old = '''  } else if (which === "kuaishou") {
    openExternal("https://www.kuaishou.com/search/" + encodeURIComponent("解安"));
    toast("正在打开快手搜索「解安」", "info");
  }
}'''
new = '''  } else if (which === "kuaishou") {
    openExternal("https://www.kuaishou.com/search/" + encodeURIComponent("解安"));
    toast("正在打开快手搜索「解安」", "info");
  } else if (which === "web") {
    openExternal("SITE_PLACEHOLDER");
    toast("正在打开官网", "info");
  }
}'''
assert old in t, "authorLink anchor missing"
t = t.replace(old, new, 1)
t = t.replace("SITE_PLACEHOLDER", SITE, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("js patched")
