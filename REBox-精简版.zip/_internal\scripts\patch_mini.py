﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"

# ---------- 1) CSS：侧边栏滚动稳定 ----------
P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()
old = ".sidebar nav { flex: 1; overflow-y: auto; min-height: 0; scrollbar-width: thin; scrollbar-color: rgba(255,255,255,.18) transparent; }"
new = (".sidebar nav { flex: 1; overflow-y: auto; min-height: 0; padding-bottom: 10px;"
       " scrollbar-width: thin; scrollbar-color: rgba(255,255,255,.18) transparent;"
       " overscroll-behavior: contain; scrollbar-gutter: stable; contain: paint;"
       " -webkit-overflow-scrolling: touch; }")
assert old in t, "css anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("css ok")

# ---------- 2) HTML：env-mini 3 -> 6 模块 ----------
P = os.path.join(D, "web", "index.html")
t = io.open(P, "r", encoding="utf-8").read()
old = '''        <div class="env-mini" id="env-mini" data-page="tools">
          <div class="mini-row"><span class="dot-state" id="mini-java"></span>Java</div>
          <div class="mini-row"><span class="dot-state" id="mini-py"></span>Python</div>
          <div class="mini-row"><span class="dot-state" id="mini-apk"></span>APK 工具链</div>
        </div>'''
new = '''        <div class="env-mini" id="env-mini" data-page="tools">
          <div class="mini-row"><span class="dot-state" id="mini-java"></span>Java / JDK</div>
          <div class="mini-row"><span class="dot-state" id="mini-py"></span>Python</div>
          <div class="mini-row"><span class="dot-state" id="mini-apk"></span>APK 工具链</div>
          <div class="mini-row"><span class="dot-state" id="mini-exe"></span>EXE 工具链</div>
          <div class="mini-row"><span class="dot-state" id="mini-hap"></span>HAP 工具链</div>
          <div class="mini-row"><span class="dot-state" id="mini-xpkg"></span>Linux / 苹果</div>
        </div>'''
assert old in t, "html anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("html ok")

# ---------- 3) JS：renderMini 补 3 个点 ----------
P = os.path.join(D, "web", "js", "app.js")
t = io.open(P, "r", encoding="utf-8").read()
old = '''  const t = e.tools;
  dot("#mini-apk", t.apktool.ok && t.jadx.ok && t.signer.ok);
}'''
new = '''  const t = e.tools;
  dot("#mini-apk", t.apktool.ok && t.jadx.ok && t.signer.ok);
  dot("#mini-exe", (t.pyinstxtractor && t.pyinstxtractor.ok) || (t.pyinstaller && t.pyinstaller.ok));
  dot("#mini-hap", !!(t.jadx && t.jadx.ok));
  dot("#mini-xpkg", (t["7zip"] && t["7zip"].ok) || (t.ghidra && t.ghidra.ok));
}'''
assert old in t, "js anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("js ok")

# ---------- 4) envdetect：加 7zip 状态 ----------
P = os.path.join(D, "app", "core", "envdetect.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '    tools["dnspy"] = {"ok": bool(dns), "version": "" if not dns else "dnSpyEx", "path": dns}'
new = (old + '\n'
       '    # 7-Zip（deb/rpm/dmg/AppImage 解包）\n'
       '    z7 = os.path.join(TOOLS_DIR, "7zip", "7z.exe")\n'
       '    tools["7zip"] = {"ok": _exists(z7), "version": "7-Zip" if _exists(z7) else "", "path": z7}')
assert old in t, "envdetect anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("envdetect ok")
