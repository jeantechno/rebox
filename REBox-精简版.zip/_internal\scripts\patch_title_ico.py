﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "web", "index.html")
t = io.open(P, "r", encoding="utf-8").read()

ICO = '''<svg viewBox="0 0 24 24"><path d="M12 2.8 20.2 7.2v9.6L12 21.2 3.8 16.8V7.2z"/><circle cx="12" cy="12" r="4.2"/><path d="m8.6 12 3.4-3.4L15.4 12M8.6 12l3.4 3.4L15.4 12"/></svg>'''

old = '<div class="logo-mark lg">R</div>'
assert old in t, "boot logo missing"
t = t.replace(old, '<div class="logo-mark lg">' + ICO + "</div>", 1)

old2 = '<div class="logo-mark">R</div>'
assert old2 in t, "title logo missing"
t = t.replace(old2, '<div class="logo-mark">' + ICO + "</div>", 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("html ok")

# CSS：徽标内 SVG 样式
P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()
old = '''.logo-mark { width: 30px; height: 30px; border-radius: 9px; display: grid; place-items: center;
  font-weight: 800; font-size: 16px; color: #04201d;
  background: linear-gradient(135deg, #5eead4, #22d3ee 55%, #7dd3fc);
  box-shadow: 0 6px 18px rgba(45,212,191,.4), inset 0 1px 0 rgba(255,255,255,.6); }'''
new = old + '''
.logo-mark svg { width: 19px; height: 19px; fill: none; stroke: #04201d; stroke-width: 1.8;
  stroke-linecap: round; stroke-linejoin: round; }
.logo-mark.lg svg { width: 44px; height: 44px; stroke-width: 1.6; }'''
assert old in t, "css logo anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("css ok")
