﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "scripts", "patch_presets.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '''old = \'\'\'  if (state.theme && state.theme.image) {
    $("#theme-bg").value = state.theme.image;
  }
  if (state.theme && state.theme.blur != null) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();\'\'\''
new = '''old = \'\'\'  state.theme = info.theme || { image: "", blur: 0 };
  if (state.theme.image) $("#theme-bg").value = state.theme.image;
  if (state.theme.blur) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();\'\'\''
new2 = new + '''
new = \'\'\'  state.theme = Object.assign({ image: "", blur: 0, gradient: "aurora" }, info.theme || {});
  if (state.theme.image) $("#theme-bg").value = state.theme.image;
  if (state.theme.blur) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();
  renderPresets();\'\'\'
assert old in t, "boot anchor missing"
t = t.replace(old, new, 1)
'''
assert old in t, "patch script anchor missing"
t = t.replace(old, new2, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("patch script fixed")
