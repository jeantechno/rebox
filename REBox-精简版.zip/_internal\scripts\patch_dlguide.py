﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"

# ---------- 后端：tool_download 加 hapsigner / dotnet 指引 ----------
P = os.path.join(D, "app", "backend.py")
t = io.open(P, "r", encoding="utf-8").read()
old = '''    def tool_download(self, name):
        if name not in toolmgr.TOOLS:
            return ""'''
new = '''    def tool_download(self, name):
        if name == "hapsigner":
            # 官方仅提供源码（需编译）或随 DevEco Studio 自带，没有预编译 jar 直链
            self.open_external("https://gitee.com/openharmony/developtools_hapsigner")
            self.open_external("https://developer.huawei.com/consumer/cn/doc/harmonyos-guides-V2/command-line-building-app-hap-hvigor-0000001553061909-V2")
            return {"ok": True, "msg": "已打开官方仓库与华为文档：hap-sign-tool 需源码编译或随 DevEco Studio 自带，获取后放入 tools\\hapsigner.jar 即自动识别。"}
        if name == "dotnet":
            # 打开 .NET 官方下载页（安装 SDK 后即可用 dotnet tool 安装 ilspycmd）
            self.open_external("https://dotnet.microsoft.com/download")
            return {"ok": True, "msg": "已打开 .NET 官方下载页；安装 SDK 后 EXE 反编译即可自动安装 ilspycmd。"}
        if name not in toolmgr.TOOLS:
            return ""'''
assert old in t, "tool_download anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("backend ok")

# ---------- 前端：按钮 + startDownload 适配 ----------
P = os.path.join(D, "web", "js", "app.js")
t = io.open(P, "r", encoding="utf-8").read()

old = '''    row(".NET SDK / ilspycmd", "命令行导出 C#（未安装时自动改用 dnSpy）", t.dotnet, "") +
    row("hap-sign-tool", "HAP 真机签名（可选：下载后放入 tools\\hapsigner.jar）", t.hapsigner || { ok: false, version: "", path: "" }, "");'''
new = '''    row(".NET SDK / ilspycmd", "命令行导出 C#（未安装时自动改用 dnSpy）", t.dotnet, btn("下载 / 安装", 'data-dl="dotnet"')) +
    row("hap-sign-tool", "HAP 真机签名（可选：获取后放入 tools\\hapsigner.jar）", t.hapsigner || { ok: false, version: "", path: "" }, btn("获取指引", 'data-dl="hapsigner"'));'''
assert old in t, "opt rows anchor missing"
t = t.replace(old, new, 1)

old = '''  const id = await state.api.tool_download(name);
  state.jobs[id] = {'''
new = '''  const id = await state.api.tool_download(name);
  if (id && typeof id === "object") {
    btn.disabled = false;
    $("#dl-console-wrap").hidden = true;
    toast(id.msg || "已打开获取指引", "ok");
    return;
  }
  state.jobs[id] = {'''
assert old in t, "startDownload anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("js ok")
