﻿# -*- coding: utf-8 -*-
import io, os, shutil
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
SITE = os.path.join(D, "..", "REBox-官网")
SRC = os.path.join(SITE, "REBox-官网.html")
ZIP = os.path.join(SITE, "REBox-精简版.zip")

def patch_html(path):
    t = io.open(path, "r", encoding="utf-8").read()
    c0 = t.count('href="REBox.exe"')
    t = t.replace('href="REBox.exe"', 'href="REBox-精简版.zip"')
    # hero CTA 下加下载说明
    old = '''    <div class="hero-meta">'''
    note = '''    <p class="dl-note">下载为完整版压缩包：解压后双击 REBox.exe 即可运行，工具链首次运行自动补齐</p>
    <div class="hero-meta">'''
    assert old in t, "hero-meta anchor missing: " + path
    t = t.replace(old, note, 1)
    # 样式
    old = '''.hero-meta{display:flex;gap:26px;justify-content:center;margin-top:52px;flex-wrap:wrap}'''
    new = '''.dl-note{margin-top:16px;font-size:12.5px;color:var(--dim2);font-weight:300;letter-spacing:.3px}
.hero-meta{display:flex;gap:26px;justify-content:center;margin-top:52px;flex-wrap:wrap}'''
    assert old in t, "hero-meta css anchor missing: " + path
    t = t.replace(old, new, 1)
    io.open(path, "w", encoding="utf-8", newline="").write(t)
    return c0

c = patch_html(SRC)
print("src hrefs replaced:", c)

# site 发布目录同步
site_dir = os.path.join(SITE, "site")
shutil.copyfile(SRC, os.path.join(site_dir, "REBox-官网.html"))
shutil.copyfile(ZIP, os.path.join(site_dir, "REBox-精简版.zip"))
if os.path.exists(os.path.join(site_dir, "REBox.exe")):
    os.remove(os.path.join(site_dir, "REBox.exe"))
print("site synced")

# 部署包-上传即用同步
dep = os.path.join(SITE, "部署包-上传即用")
patch_html(os.path.join(dep, "index.html"))
shutil.copyfile(ZIP, os.path.join(dep, "REBox-精简版.zip"))
if os.path.exists(os.path.join(dep, "REBox.exe")):
    os.remove(os.path.join(dep, "REBox.exe"))
print("deploy pack synced")

# 重新压部署包 zip
zp = os.path.join(SITE, "REBox官网-部署包.zip")
if os.path.exists(zp):
    os.remove(zp)
import zipfile
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(dep):
        for f in files:
            fp = os.path.join(root, f)
            z.write(fp, os.path.relpath(fp, dep))
print("deploy zip size:", round(os.path.getsize(zp)/1048576, 1), "MB")
