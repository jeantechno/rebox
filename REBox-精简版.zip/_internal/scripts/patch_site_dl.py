﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "..", "REBox-官网", "site", "REBox-官网.html")
t = io.open(P, "r", encoding="utf-8").read()

# 两个下载按钮改为 data-dl 引导（线上版不放 zip）
old = '<a class="nav-dl" href="REBox-精简版.zip">下载</a>'
new = '<a class="nav-dl" href="#dl" data-dl="zip">下载</a>'
assert old in t, "nav-dl missing"
t = t.replace(old, new, 1)

old = '''      <a class="btn btn-pri" href="REBox-精简版.zip">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11m0 0 4-4m-4 4-4-4M4 19h16"/></svg>
        下载 REBox
      </a>'''
new = '''      <a class="btn btn-pri" href="#dl" data-dl="zip">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11m0 0 4-4m-4 4-4-4M4 19h16"/></svg>
        获取下载
      </a>'''
assert old in t, "btn-pri missing"
t = t.replace(old, new, 1)

old = '''    <p class="dl-note">下载为完整版压缩包：解压后双击 REBox.exe 即可运行，工具链首次运行自动补齐</p>'''
new = '''    <p class="dl-note">软件包通过 QQ 交流群分发：点击「获取下载」复制群号 1124717353，进群后从群文件下载完整版（解压即用）</p>'''
assert old in t, "dl-note missing"
t = t.replace(old, new, 1)

# JS：data-dl 处理
old = '''  document.querySelectorAll('[data-channel]').forEach(function(el){'''
new = '''  document.querySelectorAll('[data-dl]').forEach(function(el){
    function act(){
      copy('1124717353',function(){show('群号已复制：1124717353，进群后于群文件下载完整版');open('https://qun.qq.com/')});
    }
    el.addEventListener('click',act);
    el.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();act();}});
  });
  document.querySelectorAll('[data-channel]').forEach(function(el){'''
assert old in t, "js data-dl anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("site html ok")

# site/ 移除 zip
z = os.path.join(D, "..", "REBox-官网", "site", "REBox-精简版.zip")
if os.path.exists(z):
    os.remove(z)
    print("zip removed from site")
