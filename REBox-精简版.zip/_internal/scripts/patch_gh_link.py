﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
old = 'openExternal("https://4m4tcmw0uum2v.doubaoapps.com/app/app_17evupfyq6u");'
new = 'openExternal("https://jeantechno.github.io/rebox/");'
for P in (os.path.join(D, "web", "js", "app.js"), os.path.join(D, "dist", "REBox", "_internal", "web", "js", "app.js")):
    t = io.open(P, "r", encoding="utf-8").read()
    assert old in t, "link anchor missing: " + P
    t = t.replace(old, new, 1)
    io.open(P, "w", encoding="utf-8", newline="").write(t)
    print("ok:", P)
