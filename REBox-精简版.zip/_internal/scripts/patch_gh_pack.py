# -*- coding: utf-8 -*-
import io, os, shutil

SITE = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox-官网"
DEP = os.path.join(SITE, "部署包-上传即用")
P = os.path.join(DEP, "index.html")
t = io.open(P, "r", encoding="utf-8").read()

# 下载按钮改回直接下载 zip（两处）
old = '<a class="nav-dl" href="#dl" data-dl="zip">下载</a>'
new = '<a class="nav-dl" href="REBox-精简版.zip">下载</a>'
assert old in t
t = t.replace(old, new, 1)

old = '''      <a class="btn btn-pri" href="#dl" data-dl="zip">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11m0 0 4-4m-4 4-4-4M4 19h16"/></svg>
        获取下载
      </a>'''
new = '''      <a class="btn btn-pri" href="REBox-精简版.zip">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11m0 0 4-4m-4 4-4-4M4 19h16"/></svg>
        下载 REBox
      </a>'''
assert old in t
t = t.replace(old, new, 1)

old = '''    <p class="dl-note">软件包通过 QQ 交流群分发：点击「获取下载」复制群号 1124717353，进群后从群文件下载完整版（解压即用）</p>'''
new = '''    <p class="dl-note">完整版压缩包：解压后双击 REBox.exe 即可运行，工具链首次运行自动补齐</p>'''
assert old in t
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("index.html ok")

# 放回精简 zip
z = os.path.join(SITE, "REBox-精简版.zip")
shutil.copyfile(z, os.path.join(DEP, "REBox-精简版.zip"))
print("zip restored")

# 上传说明改为 GitHub Pages 教程
guide = """GitHub Pages 部署教程（网页操作，无需命令行）
========================================
GitHub Pages 免费、支持任意文件（zip/exe 都能直接下载），没有 Neocities 那种格式限制。

一、准备工作
1. 用 Edge 打开 https://github.com 注册/登录账号（免费）
2. 记下你的用户名（如 reboxjean）

二、创建仓库
1. 右上角 + 号 -> New repository
2. Repository name 填：<你的用户名>.github.io
   （例如用户名是 reboxjean 就填 reboxjean.github.io，必须完全一致）
3. 选 Public（公开）
4. 勾选 Add a README file
5. 点 Create repository

三、上传文件
1. 进入仓库页面 -> 点 Add file -> Upload files
2. 把本文件夹里的这 4 项拖进去：
   - index.html
   - REBox-精简版.zip
   - assets/（整个文件夹，含 icon.png、avatar.png）
3. 页面底部 Commit changes 按钮 -> 确认提交

四、上线
1. 打开 https://<你的用户名>.github.io  就是官网（等 1~2 分钟生效）
2. 安装包下载地址：https://<你的用户名>.github.io/REBox-精简版.zip
3. 若想用自己域名：仓库 Settings -> Pages -> Custom domain 绑定

注意：不要把「上传说明.txt」传上去，它只是给你看的。
"""
with io.open(os.path.join(DEP, "上传说明.txt"), "w", encoding="utf-8") as f:
    f.write(guide)
print("guide written")
