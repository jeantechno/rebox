﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"

# 1) 源码 app.js
P = os.path.join(D, "web", "js", "app.js")
t = io.open(P, "r", encoding="utf-8").read()
old = '''  } else if (which === "web") {
    openExternal("https://xn--cjs28fo1tr01a.rth1.xyz/");
    toast("正在打开官网", "info");
  }'''
new = '''  } else if (which === "web") {
    toast("官网暂未上线，敬请期待", "info");
  }'''
assert old in t, "app.js web anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("app.js ok")

# 2) 打包版 app.js
P2 = os.path.join(D, "dist", "REBox", "_internal", "web", "js", "app.js")
if os.path.isfile(P2):
    t = io.open(P2, "r", encoding="utf-8").read()
    assert old in t, "dist app.js anchor missing"
    t = t.replace(old, new, 1)
    io.open(P2, "w", encoding="utf-8", newline="").write(t)
    print("dist app.js ok")

# 3) 官网页面 JS
P3 = os.path.join(D, "..", "REBox-官网", "REBox-官网.html")
t = io.open(P3, "r", encoding="utf-8").read()
old3 = "else if(k==='web'){open('https://xn--cjs28fo1tr01a.rth1.xyz/')}"
new3 = "else if(k==='web'){show('官网暂未上线，敬请期待')}"
assert old3 in t, "site web anchor missing"
t = t.replace(old3, new3, 1)
io.open(P3, "w", encoding="utf-8", newline="").write(t)
print("site ok")

# 4) 打包版 README 去掉失效链接
P4 = os.path.join(D, "dist", "REBox", "README.md")
t = io.open(P4, "r", encoding="utf-8").read()
t = t.replace(" ｜ 官网：https://xn--cjs28fo1tr01a.rth1.xyz/", "")
t = t.replace(" ｜ 官网：https://xn--cjs28fo1tr01a.rth1.xyz/", "")
io.open(P4, "w", encoding="utf-8", newline="").write(t)
print("readme ok")
