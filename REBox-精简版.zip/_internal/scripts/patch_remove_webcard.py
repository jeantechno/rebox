﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
SITE = os.path.join(D, "..", "REBox-官网", "REBox-官网.html")

# 1) 官网：删除「官网」卡片
t = io.open(SITE, "r", encoding="utf-8").read()
old = '''      <div class="ch web" data-channel="web" role="button" tabindex="0">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.4"/><path d="M3.6 12h16.8M12 3.6c2.2 2.2 3.3 5 3.3 8.4s-1.1 6.2-3.3 8.4c-2.2-2.2-3.3-5-3.3-8.4S9.8 5.8 12 3.6z"/></svg>
        <b>官网</b><span>解域江安 · 官方网站</span>
      </div>
    </div>'''
assert old in t, "site ch-web card missing"
t = t.replace(old, "    </div>", 1)
# 2) ch-grid 4 列 -> 3 列
old = ".ch-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:30px}"
assert old in t, "ch-grid anchor missing"
t = t.replace(old, ".ch-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:30px}", 1)
old = "@media(max-width:760px){.ch-grid{grid-template-columns:repeat(2,1fr)}}"
assert old in t, "ch-grid media anchor missing"
t = t.replace(old, "@media(max-width:560px){.ch-grid{grid-template-columns:1fr;max-width:340px;margin:30px auto 0}}", 1)
# 3) 官网 JS：web 分支移除
old = "      else if(k==='web'){show('官网暂未上线，敬请期待')}\n"
assert old in t, "site js web branch missing"
t = t.replace(old, "", 1)
io.open(SITE, "w", encoding="utf-8", newline="").write(t)
print("site ok")

# 4) REBox app.js（源码 + 打包版）：官网按钮指向新官网
for P in (os.path.join(D, "web", "js", "app.js"), os.path.join(D, "dist", "REBox", "_internal", "web", "js", "app.js")):
    if not os.path.isfile(P):
        continue
    t = io.open(P, "r", encoding="utf-8").read()
    old = '''  } else if (which === "web") {
    toast("官网暂未上线，敬请期待", "info");
  }'''
    new = '''  } else if (which === "web") {
    openExternal("https://4m4tcmw0uum2v.doubaoapps.com/app/app_17evupfyq6u");
    toast("正在打开官网", "info");
  }'''
    assert old in t, "app.js web branch missing: " + P
    t = t.replace(old, new, 1)
    io.open(P, "w", encoding="utf-8", newline="").write(t)
    print("app.js ok:", P)
