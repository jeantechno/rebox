﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "backend.py")
t = io.open(P, "r", encoding="utf-8").read()

old = '''    def win_toggle_max(self):
        w = webview.active_window()
        if w.maximized:
            w.restore()
            return False
        w.maximize()
        return True'''

new = '''    def win_toggle_max(self):
        """最大化/恢复：直接调用 Win32 API，无边框窗口下最可靠，
        ShowWindow(SW_RESTORE) 会由系统精确还原最大化前的尺寸与位置。"""
        w = webview.active_window()
        try:
            import ctypes
            user32 = ctypes.windll.user32
            hwnd = w.native.Handle.ToInt32()
            if user32.IsZoomed(hwnd):
                user32.ShowWindow(hwnd, 9)  # SW_RESTORE
                return False
            user32.ShowWindow(hwnd, 3)  # SW_MAXIMIZE
            return True
        except Exception:
            # 回退：pywebview 原生方式
            if w.maximized:
                w.restore()
                return False
            w.maximize()
            return True'''

assert old in t, "win_toggle_max not found"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("win_toggle_max patched")
