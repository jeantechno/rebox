/* ============================================================
   REBox frontend logic
   ============================================================ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const state = {
  api: null, workspace: "", version: "",
  env: null, running: null, jobs: {},
  exeInfo: null,
};

const KIND_LABEL = {
  pyinstaller: "PyInstaller 打包程序", dotnet: ".NET 程序集", dotnet_sc: ".NET 自包含发布",
  native: "原生 PE 程序", nuitka: "Nuitka 编译程序", py2exe: "py2exe 程序", go: "Go 程序",
  electron: "Electron 应用", elf: "Linux ELF", macho: "macOS 程序", script: "脚本", unknown: "未知类型",
};
const START_TEXT = {
  pyinstaller: "提取 PyInstaller 归档（.pyc）",
  dotnet: "反编译为 C# 源码", dotnet_sc: "反编译为 C# 源码",
  native: "用 Ghidra 导出伪 C 代码", nuitka: "用 Ghidra 导出伪 C 代码",
  py2exe: "用 Ghidra 分析", go: "用 Ghidra 分析",
};

/* ---------------- 启动 ---------------- */
let booted = false;
function bootWhenReady() {
  if (booted) return;
  // 不能只判断 window.pywebview.api 是否存在：pywebview 会先注入空 api 对象，
  // 再由 finish.js 异步填充方法（打包为单文件 exe 后启动更慢，竞态必现）。
  // 必须确认具体方法已注册，或收到 pywebviewready 事件后再启动。
  const ready =
    window.pywebview &&
    window.pywebview.api &&
    typeof window.pywebview.api.app_init === "function";
  if (ready) {
    booted = true;
    state.api = window.pywebview.api;
    init();
  } else {
    setTimeout(bootWhenReady, 60);
  }
}
window.addEventListener("pywebviewready", bootWhenReady);

async function init() {
  let info;
  try {
    info = await state.api.app_init();
  } catch (e) {
    document.body.innerHTML = '<div style="color:#fff;padding:40px;font-family:sans-serif">初始化失败：' + e + "</div>";
    return;
  }
  state.workspace = info.workspace;
  state.version = info.version;
  const verEl = document.querySelector('.page[data-page="about"] .page-head p');
  if (verEl) verEl.textContent = "v" + info.version;

  bindStatic();

  // 应用已保存的外观设置
  state.theme = Object.assign({ image: "", blur: 0, gradient: "aurora" }, info.theme || {});
  if (state.theme.image) {
    $("#theme-bg").value = state.theme.image;
    const data = await state.api.theme_image_data();
    if (data) state.theme.image = data;
  }
  if (state.theme.blur) {
    $("#theme-blur").value = state.theme.blur;
    $("#theme-blur-val").textContent = state.theme.blur + "px";
  }
  applyTheme();
  renderPresets();

  if (!info.disclaimer_accepted) {
    $("#boot").classList.add("hide");
    $("#disclaimer").hidden = false;
  } else {
    enter();
  }
}

function enter() {
  $("#disclaimer").hidden = true;
  $("#boot").classList.add("hide");
  const app = $("#app");
  app.hidden = false;
  app.style.animation = "pageIn .5s cubic-bezier(.22,.8,.26,1) both";
  setTimeout(() => $("#boot").remove(), 600);
  moveNavCursor();
  refreshEnv();
}

/* ---------------- Toast ---------------- */
function toast(msg, type = "info", ms = 4200) {
  const icons = { ok: "✓", error: "!", warn: "!", info: "i" };
  const el = document.createElement("div");
  el.className = "toast " + type;
  el.innerHTML = '<span class="ti">' + (icons[type] || "i") + "</span><span></span>";
  el.children[1].textContent = msg;
  $("#toasts").appendChild(el);
  setTimeout(() => {
    el.classList.add("leaving");
    setTimeout(() => el.remove(), 320);
  }, ms);
}

/* ---------------- 路由 ---------------- */
function goto(page) {
  try {
    $$(".nav-item").forEach((n) => n.classList.toggle("active", n.dataset.page === page));
    $$(".page").forEach((p) => p.classList.toggle("active", p.dataset.page === page));
    const c = $("#content");
    if (c) c.scrollTop = 0;
    moveNavCursor();
    if (page === "tools") refreshEnv();
  } catch (e) { reportErr(e); }
}

function moveNavCursor() {
  const nav = $("#nav");
  let cursor = nav.querySelector(".nav-cursor");
  const active = nav.querySelector(".nav-item.active");
  if (!active) return;
  if (!cursor) {
    cursor = document.createElement("div");
    cursor.className = "nav-cursor";
    nav.prepend(cursor);
  }
  cursor.style.height = active.offsetHeight + "px";
  cursor.style.transform = "translateY(" + active.offsetTop + "px)";
}

/* ---------------- 静态绑定 ---------------- */
function bindStatic() {
  // 窗口控制（带平滑过渡动画）
  $("#win-min").addEventListener("click", () => windowAnim("min"));
  $("#win-max").addEventListener("click", () => windowAnim("max"));
  $("#win-close").addEventListener("click", () => windowAnim("close"));
  $$(".wbtn").forEach((b) => b.addEventListener("mousedown", (e) => e.stopPropagation()));

  // 免责声明
  $("#agree").addEventListener("click", async () => {
    await state.api.accept_disclaimer();
    toast("欢迎使用 REBox，请合规使用", "ok");
    enter();
  });
  $("#disagree").addEventListener("click", () => state.api.win_close());

  // 导航（仅匹配真正的导航目标，避免 .page 区块自带的 data-page 短路其他交互）
  document.addEventListener("click", (e) => {
    const navGo = e.target.closest(".nav-item[data-page], .env-mini[data-page], .env-strip[data-page], a[data-page]");
    if (navGo) { goto(navGo.dataset.page); return; }
    const go = e.target.closest("[data-go]");
    if (go) { goto(go.dataset.go); return; }
    const browse = e.target.closest("[data-browse]");
    if (browse) { onBrowse(browse.dataset.browse, browse); return; }
    const clear = e.target.closest("[data-clear]");
    if (clear) { $("#" + clear.dataset.clear).innerHTML = ""; return; }
    const dl = e.target.closest("[data-dl]");
    if (dl) { startDownload(dl.dataset.dl, dl); return; }
    const pip = e.target.closest("[data-pip]");
    if (pip) { startPip(pip.dataset.pip, pip); return; }
    const jpick = e.target.closest("[data-java-pick]");
    if (jpick) { pickRuntime("java"); return; }
    const ppick = e.target.closest("[data-py-pick]");
    if (ppick) { pickRuntime("python"); return; }
    const ext = e.target.closest("[data-ext]");
    if (ext) { authorLink(ext.dataset.ext); return; }
    const pre = e.target.closest("[data-preset]");
    if (pre) { applyPreset(pre.dataset.preset); return; }
  });
  $$(".nav-item").forEach((n) => n.addEventListener("click", () => goto(n.dataset.page)));
  window.addEventListener("resize", moveNavCursor);

  // 分段控件
  $$(".segmented").forEach((seg) => {
    seg.addEventListener("click", (e) => {
      const b = e.target.closest(".seg");
      if (!b) return;
      seg.querySelectorAll(".seg").forEach((x) => x.classList.toggle("active", x === b));
      if (seg.id === "apkb-sign-seg") $("#apkb-ks").hidden = b.dataset.v !== "custom";
    });
  });

  // 选择后联动
  $("#exed-file").addEventListener("change", identifyExe);
  $("#exeb-file").addEventListener("change", (e) => {
    const name = $("#exeb-name");
    const v = e.target.value;
    if (!name.value && v) name.value = v.split(/[\\/]/).pop().replace(/\.py$/i, "");
  });

  // 各功能开始 / 取消 / 打开
  $("#apkd-start").addEventListener("click", () => startJob(pages.apkd));
  $("#apkd-cancel").addEventListener("click", cancelJob);
  $("#apkd-open").addEventListener("click", () => state.api.open_path($("#apkd-open").dataset.path));
  $("#apkb-start").addEventListener("click", () => startJob(pages.apkb));
  $("#apkb-cancel").addEventListener("click", cancelJob);
  $("#apkb-open").addEventListener("click", () => state.api.open_path($("#apkb-open").dataset.path));
  $("#exed-identify").addEventListener("click", identifyExe);
  $("#exed-start").addEventListener("click", () => startJob(pages.exed));
  $("#exed-cancel").addEventListener("click", cancelJob);
  $("#exed-open").addEventListener("click", () => state.api.open_path($("#exed-open").dataset.path));
  $("#exed-dnspy").addEventListener("click", async () => {
    const p = $("#exed-file").value;
    if (p) await state.api.dnspy_open(p);
  });
  $("#exeb-start").addEventListener("click", () => startJob(pages.exeb));
  $("#exeb-cancel").addEventListener("click", cancelJob);
  $("#exeb-open").addEventListener("click", () => state.api.open_path($("#exeb-open").dataset.path));

  $("#tools-open-ws").addEventListener("click", () => state.api.open_path(state.workspace));
  // 主题：选择背景 / 恢复默认 / 模糊滑块
  $("#theme-bg").addEventListener("change", async (e) => {
    const v = e.target.value;
    if (!v) return;
    const p = await state.api.theme_import(v);
    if (p) {
      const data = await state.api.theme_image_data();
      state.theme.image = data || "";
      await state.api.save_settings({ theme_image: p });
      applyTheme();
      toast("背景已更新，立即生效", "ok");
    } else {
      toast("背景导入失败", "error");
    }
  });
  $("#theme-reset").addEventListener("click", async () => {
    await state.api.save_settings({ theme_image: "", theme_blur: 0 });
    state.theme = { image: "", blur: 0 };
    $("#theme-bg").value = "";
    $("#theme-blur").value = 0;
    $("#theme-blur-val").textContent = "0px";
    applyTheme();
    toast("已恢复默认极光背景", "ok");
  });
  const blurEl = $("#theme-blur");
  blurEl.addEventListener("input", () => {
    $("#theme-blur-val").textContent = blurEl.value + "px";
    applyTheme(null, blurEl.value);
  });
  blurEl.addEventListener("change", async () => {
    state.theme.blur = parseInt(blurEl.value, 10) || 0;
    await state.api.save_settings({ theme_blur: state.theme.blur });
  });

}

async function onBrowse(spec) {
  const parts = spec.split(":");
  let val = "";
  if (parts[0] === "folder") val = await state.api.pick_folder();
  else val = await state.api.pick_file(parts[1] || "exe");
  const target = $("#" + parts[parts.length - 1]);
  if (val && target) {
    target.value = val;
    target.dispatchEvent(new Event("change"));
  }
}

/* ---------------- 环境状态 ---------------- */
async function refreshEnv() {
  try {
    state.env = await state.api.refresh_env();
  } catch (e) { return; }
  renderMini();
  renderStrip();
  renderTools();
}

function dot(id, ok) {
  const el = $(id);
  if (!el) return;
  el.className = "dot-state " + (ok ? "ok" : "bad");
}

function renderMini() {
  const e = state.env;
  dot("#mini-java", e.java.ok);
  dot("#mini-py", e.python.ok);
  const t = e.tools;
  dot("#mini-apk", t.apktool.ok && t.jadx.ok && t.signer.ok);
  dot("#mini-exe", (t.pyinstxtractor && t.pyinstxtractor.ok) || (t.pyinstaller && t.pyinstaller.ok));
  dot("#mini-hap", !!(t.jadx && t.jadx.ok));
  dot("#mini-xpkg", (t["7zip"] && t["7zip"].ok) || (t.ghidra && t.ghidra.ok));
}

function pill(label, ok, ver) {
  return '<div class="env-pill"><span class="dot-state ' + (ok ? "ok" : "bad") + '"></span><b>' + label +
    '</b><span class="v">' + (ver || (ok ? "就绪" : "未就绪")) + "</span></div>";
}

function renderStrip() {
  const e = state.env, t = e.tools;
  const apkOk = t.apktool.ok && t.jadx.ok && t.signer.ok;
  const nativeOk = t.ghidra.ok || t.dnspy.ok;
  $("#env-strip").innerHTML =
    pill("Java / JDK", e.java.ok, e.java.version ? "JDK " + e.java.version : "") +
    pill("Python", e.python.ok, e.python.version || "") +
    pill("APK 工具链", apkOk, apkOk ? "apktool · jadx · signer" : "工具中心可修复") +
    '<div class="env-pill"><span class="dot-state ' + (nativeOk ? "ok" : "warn") + '"></span><b>原生 / .NET 逆向</b><span class="v">' +
    (nativeOk ? "Ghidra / dnSpy 就绪" : "可选，工具中心下载") + "</span></div>";
}

function stateHtml(info) {
  if (info.ok) return '<div class="tool-state ok"><span class="dot-state ok"></span><span class="t">已就绪</span></div>';
  return '<div class="tool-state bad"><span class="dot-state bad"></span><span class="t">未就绪</span></div>';
}

function row(name, desc, info, action) {
  return '<div class="tool-row"><div class="tool-name">' + name + "<small>" + desc + '</small></div>' +
    stateHtml(info) + '<div class="tool-path">' + (info.path || info.version || "") + "</div>" +
    '<div>' + action + "</div></div>";
}

function btn(label, attr, cls = "ghost sm", extra = "") {
  return '<button class="btn ' + cls + '" ' + attr + " " + extra + ">" + label + "</button>";
}

function renderTools() {
  const e = state.env, t = e.tools;
  $("#env-table").innerHTML =
    row("Java / JDK", "APK 工具链与 Ghidra 依赖，建议 JDK 17+",
      e.java, btn("手动选择", "data-java-pick")) +
    row("Python", "EXE 提取与 PyInstaller 打包依赖",
      { ok: e.python.ok, version: e.python.version + (e.python.pip ? " · pip 正常" : " · pip 异常"), path: e.python.exe },
      btn("手动选择", "data-py-pick"));

  $("#core-table").innerHTML =
    row("apktool", "APK 解包 / 回编译", t.apktool, btn("下载 / 修复", 'data-dl="apktool"')) +
    row("jadx", "DEX → Java 源码（APK / HAP 内 dex）", t.jadx, btn("下载 / 修复", 'data-dl="jadx"')) +
    row("uber-apk-signer", "zipalign 对齐 + 签名", t.signer, btn("下载 / 修复", 'data-dl="signer"')) +
    row("7-Zip", "deb / rpm / dmg / AppImage 解包（Linux / 苹果）", t["7zip"] || { ok: false, version: "", path: "" }, btn("下载 / 修复", 'data-dl="7zip"'));

  $("#opt-table").innerHTML =
    row("PyInstaller", "Python → EXE 打包（使用时也会自动安装）", t.pyinstaller, btn("立即安装", 'data-pip="pyinstaller"')) +
    row("pyinstxtractor-ng", "PyInstaller 归档提取（使用时自动安装）", t.pyinstxtractor, btn("立即安装", 'data-pip="pyinstxtractor-ng"')) +
    row("Ghidra", "原生 PE 反编译为伪 C，约 400MB", t.ghidra, btn("下载 Ghidra", 'data-dl="ghidra"', "ghost sm")) +
    row("dnSpyEx", ".NET 图形化反编译器", t.dnspy, btn("下载 dnSpy", 'data-dl="dnspy"', "ghost sm")) +
    row(".NET SDK / ilspycmd", "命令行导出 C#（未安装时自动改用 dnSpy）", t.dotnet, btn("下载 / 安装", 'data-dl="dotnet"')) +
    row("hap-sign-tool", "HAP 真机签名（可选：获取后放入 tools\hapsigner.jar）", t.hapsigner || { ok: false, version: "", path: "" }, btn("获取指引", 'data-dl="hapsigner"'));
  $("#tools-workspace").value = state.workspace;
}

async function pickRuntime(kind) {
  const p = await state.api.pick_file("exe");
  if (!p) return;
  const res = kind === "java" ? await state.api.set_java(p) : await state.api.set_python(p);
  if (res.ok) { toast("已保存并检测通过", "ok"); refreshEnv(); }
  else toast(res.msg || "无法使用该程序", "error");
}

/* ---------------- 任务系统 ---------------- */
const pages = {
  apkd: {
    console: "console-apkd", prog: "prog-apkd", spin: "apkd-spin", steps: "steps-apkd",
    start: "apkd-start", cancel: "apkd-cancel", open: "apkd-open", method: "apk_decompile",
    collect() {
      const apk = $("#apkd-file").value;
      if (!apk) { toast("请先选择 APK 文件", "warn"); return null; }
      return {
        apk, outdir: $("#apkd-out").value || state.workspace,
        do_apktool: $("#apkd-opt-apktool").checked,
        do_jadx: $("#apkd-opt-jadx").checked,
        bad_code: $("#apkd-opt-bad").checked,
      };
    },
  },
  apkb: {
    console: "console-apkb", prog: "prog-apkb", spin: "apkb-spin", steps: "steps-apkb",
    start: "apkb-start", cancel: "apkb-cancel", open: "apkb-open", method: "apk_build",
    collect() {
      const project = $("#apkb-proj").value;
      if (!project) { toast("请选择 apktool 工程目录", "warn"); return null; }
      const custom = $("#apkb-sign-seg").querySelector(".seg.active").dataset.v === "custom";
      return {
        project, outdir: $("#apkb-out").value || state.workspace,
        keystore: custom ? $("#apkb-ks-file").value : null,
        alias: custom ? $("#apkb-ks-alias").value : null,
        ks_pass: custom ? $("#apkb-ks-pass").value : null,
        key_pass: custom ? $("#apkb-ks-keypass").value : null,
      };
    },
  },
  exed: {
    console: "console-exed", prog: "prog-exed", spin: "exed-spin", steps: "steps-exed",
    start: "exed-start", cancel: "exed-cancel", open: "exed-open", method: "exe_decompile",
    collect() {
      const path = $("#exed-file").value;
      if (!path) { toast("请先选择程序文件", "warn"); return null; }
      if (!state.exeInfo) { toast("请先识别程序类型", "warn"); return null; }
      const kind = state.exeInfo.kind;
      if (!START_TEXT[kind]) { toast("该类型不支持自动反编译，请看识别说明", "warn"); return null; }
      return { path, outdir: $("#exed-out").value || state.workspace, kind:
        (kind === "dotnet" || kind === "dotnet_sc") ? "dotnet" : kind };
    },
  },
  exeb: {
    console: "console-exeb", prog: "prog-exeb", spin: "exeb-spin", steps: "steps-exeb",
    start: "exeb-start", cancel: "exeb-cancel", open: "exeb-open", method: "exe_build",
    collect() {
      const script = $("#exeb-file").value;
      if (!script) { toast("请选择入口脚本 .py", "warn"); return null; }
      const adddata = $("#exeb-adddata").value.split("\n").map((s) => s.trim()).filter(Boolean);
      return {
        script,
        name: $("#exeb-name").value || script.split(/[\\/]/).pop().replace(/\.py$/i, ""),
        distdir: $("#exeb-out").value || "",
        onefile: $("#exeb-mode-seg").querySelector(".seg.active").dataset.v === "onefile",
        windowed: $("#exeb-windowed").checked,
        icon: $("#exeb-icon").value || "",
        adddata, hidden: $("#exeb-hidden").value || "",
      };
    },
  },
  hapd: {
    console: "console-hapd", prog: "prog-hapd", spin: "hapd-spin", steps: "steps-hapd",
    start: "hapd-start", cancel: "hapd-cancel", open: "hapd-open", method: "hap_decompile",
    collect() {
      const file = $("#hapd-file").value;
      if (!file) { toast("请先选择 HAP 文件", "warn"); return null; }
      return {
        hap: file, outdir: $("#hapd-out").value || state.workspace,
        do_java: $("#hapd-opt-java").checked,
        do_res: $("#hapd-opt-res").checked,
      };
    },
  },
  hapb: {
    console: "console-hapb", prog: "prog-hapb", spin: "hapb-spin", steps: "steps-hapb",
    start: "hapb-start", cancel: "hapb-cancel", open: "hapb-open", method: "hap_build",
    collect() {
      const project = $("#hapb-proj").value;
      if (!project) { toast("请选择 HAP 工程目录", "warn"); return null; }
      return { project, outdir: $("#hapb-out").value || state.workspace };
    },
  },
  lnxd: {
    console: "console-lnxd", prog: "prog-lnxd", spin: "lnxd-spin", steps: "steps-lnxd",
    start: "lnxd-start", cancel: "lnxd-cancel", open: "lnxd-open", method: "linux_decompile",
    collect() {
      const file = $("#lnxd-file").value;
      if (!file) { toast("请先选择软件包文件", "warn"); return null; }
      return { file, outdir: $("#lnxd-out").value || state.workspace, ghidra: $("#lnxd-opt-ghidra").checked };
    },
  },
  lnxb: {
    console: "console-lnxb", prog: "prog-lnxb", spin: "lnxb-spin", steps: "steps-lnxb",
    start: "lnxb-start", cancel: "lnxb-cancel", open: "lnxb-open", method: "linux_build",
    collect() {
      const project = $("#lnxb-proj").value;
      if (!project) { toast("请选择要打包的目录", "warn"); return null; }
      return { project, outdir: $("#lnxb-out").value || state.workspace };
    },
  },
  macd: {
    console: "console-macd", prog: "prog-macd", spin: "macd-spin", steps: "steps-macd",
    start: "macd-start", cancel: "macd-cancel", open: "macd-open", method: "apple_decompile",
    collect() {
      const file = $("#macd-file").value;
      if (!file) { toast("请先选择软件包文件", "warn"); return null; }
      return { file, outdir: $("#macd-out").value || state.workspace, ghidra: $("#macd-opt-ghidra").checked };
    },
  },
  macb: {
    console: "console-macb", prog: "prog-macb", spin: "macb-spin", steps: "steps-macb",
    start: "macb-start", cancel: "macb-cancel", open: "macb-open", method: "apple_build",
    collect() {
      const project = $("#macb-proj").value;
      if (!project) { toast("请选择要打包的目录", "warn"); return null; }
      return { project, outdir: $("#macb-out").value || state.workspace };
    },
  },
};

async function startJob(cfg) {
  if (state.running) { toast("已有任务正在运行，请等待或取消", "warn"); return; }
  const params = cfg.collect();
  if (!params) return;

  const con = $("#" + cfg.console);
  con.innerHTML = "";
  resetSteps(cfg.steps);
  setStep(cfg.steps, 1);
  const fill = $("#" + cfg.prog);
  fill.className = "pfill indeterminate";
  fill.style.width = "";
  $("#" + cfg.spin).hidden = false;
  $("#" + cfg.start).disabled = true;
  $("#" + cfg.cancel).hidden = false;
  $("#" + cfg.open).hidden = true;

  let id;
  try {
    id = await state.api[cfg.method](params);
  } catch (e) {
    toast("启动失败：" + e, "error");
    jobUiReset(cfg);
    return;
  }
  state.jobs[id] = { cfg, artifact: null };
  state.running = id;
}

async function startDownload(name, btn) {
  if (state.running) { toast("已有任务正在运行", "warn"); return; }
  $("#dl-console-wrap").hidden = false;
  const con = $("#console-tools");
  con.innerHTML = "";
  const fill = $("#prog-tools");
  fill.className = "pfill indeterminate";
  btn.disabled = true;
  const id = await state.api.tool_download(name);
  if (id && typeof id === "object") {
    btn.disabled = false;
    $("#dl-console-wrap").hidden = true;
    toast(id.msg || "已打开获取指引", "ok");
    return;
  }
  state.jobs[id] = {
    download: true, btn,
    cfg: { console: "console-tools", prog: "prog-tools", spin: null, steps: null, start: null, cancel: null, open: null },
    artifact: null,
  };
  state.running = id;
}

async function startPip(pkg, btn) {
  if (state.running) { toast("已有任务正在运行", "warn"); return; }
  if (!state.api.pip_ensure) return;
  $("#dl-console-wrap").hidden = false;
  $("#console-tools").innerHTML = "";
  const fill = $("#prog-tools");
  fill.className = "pfill indeterminate";
  btn.disabled = true;
  const id = await state.api.pip_ensure(pkg);
  state.jobs[id] = {
    download: true, btn,
    cfg: { console: "console-tools", prog: "prog-tools", spin: null, steps: null, start: null, cancel: null, open: null },
    artifact: null,
  };
  state.running = id;
}

function cancelJob() {
  if (state.running) state.api.job_cancel(state.running);
}

function resetSteps(sel) {
  const root = $("#" + sel);
  if (!root) return;
  root.querySelectorAll(".step").forEach((s) => s.classList.remove("active", "done", "error"));
  root.querySelectorAll(".sline").forEach((l) => l.classList.remove("done"));
  root.querySelector(".step").classList.add("active");
}
function setStep(sel, idx) {
  const root = $("#" + sel);
  if (!root) return;
  const steps = root.querySelectorAll(".step");
  const lines = root.querySelectorAll(".sline");
  steps.forEach((s, i) => {
    s.classList.toggle("done", i < idx);
    s.classList.toggle("active", i === idx);
  });
  lines.forEach((l, i) => l.classList.toggle("done", i < idx));
}
function finishSteps(sel, ok) {
  const root = $("#" + sel);
  if (!root) return;
  const steps = root.querySelectorAll(".step");
  const lines = root.querySelectorAll(".sline");
  steps.forEach((s) => { s.classList.remove("active"); s.classList.toggle("done", ok); if (!ok) s.classList.add("error"); });
  lines.forEach((l) => l.classList.toggle("done", ok));
}

function jobUiReset(cfg) {
  if (cfg.start) { const el = document.getElementById(cfg.start); if (el) el.disabled = false; }
  if (cfg.cancel) $("#" + cfg.cancel).hidden = true;
  if (cfg.spin) $("#" + cfg.spin).hidden = true;
}

/* ---------------- 后端事件入口 ---------------- */
window.REBox = {
  event(ev) {
    const job = state.jobs[ev.id];
    switch (ev.type) {
      case "log":
        if (job) appendLines(job.cfg.console, ev.lines);
        break;
      case "progress":
        if (job) {
          const fill = $("#" + job.cfg.prog);
          fill.classList.remove("indeterminate");
          fill.style.width = ev.pct + "%";
        }
        break;
      case "step":
        break;
      case "artifact":
        if (job) {
          job.artifact = ev.path;
          if (job.cfg.open) {
            const b = $("#" + job.cfg.open);
            b.hidden = false;
            b.dataset.path = ev.path;
          }
        }
        break;
      case "done":
        onJobDone(ev, job);
        break;
    }
  },
};

function appendLines(id, lines) {
  const con = $("#" + id);
  if (!con) return;
  const frag = document.createDocumentFragment();
  (lines || []).forEach(({ t, l }) => {
    const span = document.createElement("span");
    span.className = "ln l-" + (l || "out");
    span.textContent = t;
    frag.appendChild(span);
  });
  con.appendChild(frag);
  con.scrollTop = con.scrollHeight;
}

function onJobDone(ev, job) {
  const cfg = job ? job.cfg : null;
  if (cfg) {
    finishSteps(cfg.steps, ev.ok);
    const fill = $("#" + cfg.prog);
    fill.classList.remove("indeterminate");
    fill.style.width = ev.ok ? "100%" : fill.style.width;
    jobUiReset(cfg);
    if (job.artifact && cfg.open) {
      const b = $("#" + cfg.open);
      b.hidden = false;
      b.dataset.path = job.artifact;
    }
  }
  if (job && job.download) {
    if (job.btn) job.btn.disabled = false;
    refreshEnv();
  }
  state.running = null;
  if (ev.ok) toast(ev.summary || "任务完成", "ok", 5200);
  else toast(ev.summary || "任务未成功，请查看日志", "error", 6000);
}

/* ---------------- EXE 识别 ---------------- */
async function identifyExe() {
  const path = $("#exed-file").value;
  const box = $("#exed-result");
  if (!path) return;
  const info = await state.api.exe_identify(path);
  if (!info || !info.ok) { toast("无法识别该文件", "error"); return; }
  state.exeInfo = info;

  $("#exed-kind").textContent = KIND_LABEL[info.kind] || info.kind;
  const meta = [];
  if (info.arch) meta.push(info.arch);
  if (info.size_mb) meta.push(info.size_mb + " MB");
  if (info.overlay > 1024) meta.push("覆盖区 " + (info.overlay / 1048576).toFixed(1) + " MB");
  if (info.pyver) meta.push("Python " + info.pyver);
  if (info.is_dll) meta.push("DLL");
  $("#exed-meta").innerHTML = meta.map((m) => "<span>" + m + "</span>").join("");
  $("#exed-hints").innerHTML = (info.hints || []).map((h) => "<li>" + h + "</li>").join("");
  box.hidden = false;
  box.style.animation = "none"; void box.offsetWidth; box.style.animation = "";

  const start = $("#exed-start");
  const outfield = $("#exed-outfield");
  if (START_TEXT[info.kind]) {
    start.hidden = false;
    start.innerHTML = '<svg viewBox="0 0 24 24"><path d="M6 4l14 8-14 8z"/></svg>' + START_TEXT[info.kind];
    outfield.hidden = false;
  } else {
    start.hidden = true;
    outfield.hidden = true;
  }
  // dnSpy 按钮
  const dn = state.env && state.env.tools && state.env.tools.dnspy.ok;
  $("#exed-dnspy").hidden = !(dn && (info.kind === "dotnet" || info.kind === "dotnet_sc"));
}

/* ---------------- 窗口过渡动画 ---------------- */
let winAnimTimer = null;
function windowAnim(which) {
  const app = $("#app");
  if (!app || winAnimTimer) return;
  // 清除 enter() 的 pageIn 入场动画：fill:both 会让动画层的 transform/opacity
  // 一直覆盖内联样式，导致过渡动画不生效
  app.style.animation = "none";
  if (which === "min") {
    app.style.transition = "transform 200ms cubic-bezier(.5,.05,.75,.4), opacity 200ms ease";
    app.style.transformOrigin = "50% 88%";
    void app.offsetWidth;
    app.style.transform = "scale(.88) translateY(26px)";
    app.style.opacity = "0";
    winAnimTimer = setTimeout(() => { winAnimTimer = null; state.api.win_min(); }, 200);
  } else if (which === "close") {
    app.style.transition = "transform 150ms ease, opacity 150ms ease";
    app.style.transformOrigin = "50% 50%";
    void app.offsetWidth;
    app.style.transform = "scale(.96)";
    app.style.opacity = "0";
    winAnimTimer = setTimeout(() => { winAnimTimer = null; state.api.win_close(); }, 150);
  } else if (which === "max") {
    app.style.transition = "transform 140ms var(--ease)";
    void app.offsetWidth;
    app.style.transform = "scale(.985)";
    setTimeout(async () => {
      app.style.transition = "transform 220ms var(--ease)";
      app.style.transform = "";
      let maxed = false;
      try { maxed = await state.api.win_toggle_max(); } catch (e) {}
      updateMaxIcon(maxed);
    }, 140);
  }
}
function updateMaxIcon(maxed) {
  const b = $("#win-max");
  if (!b) return;
  b.innerHTML = maxed
    ? '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 6V4h11v11h-2"/></svg>'
    : '<svg viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="2"/></svg>';
}
window.REBox.onRestored = () => {
  const app = $("#app");
  if (!app) return;
  app.style.transition = "transform 240ms var(--ease), opacity 220ms ease";
  app.style.transformOrigin = "50% 88%";
    void app.offsetWidth;
  app.style.transform = "scale(.94)";
  app.style.opacity = ".4";
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      app.style.transform = "";
      app.style.opacity = "";
      setTimeout(() => { app.style.transition = ""; }, 260);
    });
  });
};

/* ---------------- 前端错误上报（用于排查） ---------------- */
function reportErr(err) {
  try {
    if (state.api && state.api.frontend_error) state.api.frontend_error(String(err));
  } catch (_) {}
}
window.addEventListener("error", (e) => reportErr(e.message || e.error));
window.addEventListener("unhandledrejection", (e) => reportErr(e.reason || "unhandled rejection"));

bootWhenReady();


/* ---------------- 外观与创作者 ---------------- */
/* PRESET_START */
const PRESETS = [
  { id: "aurora", name: "深空极光", blur: 6,
    grad: "radial-gradient(120% 130% at 15% 10%, #1c5a7a 0%, #0e2a4a 38%, #05080f 100%), radial-gradient(70% 55% at 82% 18%, rgba(45,212,191,.30), transparent 60%), radial-gradient(85% 65% at 55% 98%, rgba(56,189,248,.18), transparent 65%)" },
  { id: "mint", name: "液态薄荷", blur: 8,
    grad: "linear-gradient(140deg, #022c22 0%, #064e3b 45%, #0f766e 100%)" },
  { id: "ocean", name: "深海蓝", blur: 8,
    grad: "linear-gradient(140deg, #0b1730 0%, #12263f 52%, #1e3a5f 100%)" },
  { id: "amber", name: "鎏金琥珀", blur: 8,
    grad: "linear-gradient(140deg, #3d1507 0%, #7c2d12 48%, #b45309 100%)" },
];
/* PRESET_END */
function applyTheme(imgOverride, blurOverride, gradOverride) {
  const aurora = $("#aurora");
  if (!aurora) return;
  const image = imgOverride || (state.theme && state.theme.image) || "";
  const blur = blurOverride != null ? blurOverride : ((state.theme && state.theme.blur) || 0);
  const gid = gradOverride || (state.theme && state.theme.gradient) || "aurora";
  const grad = PRESETS.find((p) => p.id === gid);
  if (image && image.indexOf("data:") === 0) {
    aurora.style.backgroundImage = 'url("' + image + '")';
    aurora.style.backgroundSize = "cover";
    aurora.style.backgroundPosition = "center";
  } else if (grad && grad.id !== "aurora") {
    aurora.style.backgroundImage = grad.grad;
  } else {
    aurora.style.backgroundImage = "";
  }
  aurora.style.filter = blur > 0 ? "blur(" + blur + "px) saturate(1.15)" : "";
}

/* 创作者跳转：QQ 群复制群号并打开 QQ 群主页；抖音/快手打开搜索页。
   若有官方主页直链（如抖音 sec_uid / 快手 profile id），可替换为直链 URL。 */
function openExternal(url) {
  try { state.api.open_external(url); } catch (e) { window.open(url, "_blank"); }
}
function authorLink(which) {
  if (which === "qq") {
    try { navigator.clipboard.writeText("1124717353"); } catch (e) {}
    openExternal("https://qun.qq.com/");
    toast("群号 1124717353 已复制，在 QQ 中粘贴搜索即可加入交流群", "ok", 5200);
  } else if (which === "douyin") {
    openExternal("https://www.douyin.com/search/" + encodeURIComponent("解域江安"));
    toast("正在打开抖音搜索「解域江安」", "info");
  } else if (which === "kuaishou") {
    openExternal("https://www.kuaishou.com/search/" + encodeURIComponent("解安"));
    toast("正在打开快手搜索「解安」", "info");
  } else if (which === "web") {
    openExternal("https://4m4tcmw0uum2v.doubaoapps.com/app/app_17evupfyq6u");
    toast("正在打开官网", "info");
  }
}

function renderPresets() {
  const grid = $("#preset-grid");
  if (!grid) return;
  const cur = (state.theme && state.theme.gradient) || "aurora";
  grid.innerHTML = PRESETS.map((p) =>
    '<button class="preset-card' + (p.id === cur ? " on" : "") + '" data-preset="' + p.id + '">' +
    '<i style="background:' + p.grad + '"></i><span>' + p.name + "</span></button>").join("");
}
function applyPreset(id) {
  const p = PRESETS.find((x) => x.id === id) || PRESETS[0];
  state.theme.image = "";
  state.theme.gradient = p.id;
  if (p.blur != null) {
    state.theme.blur = p.blur;
    const bl = $("#theme-blur");
    if (bl) { bl.value = p.blur; $("#theme-blur-val").textContent = p.blur + "px"; }
  }
  const bg = $("#theme-bg");
  if (bg) bg.value = "";
  state.api.save_settings({ theme_image: "", theme_gradient: p.id, theme_blur: state.theme.blur });
  applyTheme();
  renderPresets();
  toast("已切换「" + p.name + "」风格", "ok");
}
