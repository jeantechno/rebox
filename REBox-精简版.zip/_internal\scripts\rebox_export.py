# @category REBox
# @runtime Jython
# Ghidra 无头(headless)反编译脚本：把所有函数导出为伪 C，并输出函数清单与程序信息。
# 由 REBox 通过 analyzeHeadless -postScript 调用，参数 1 为输出目录。
import os
from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor

args = getScriptArgs()
outdir = args[0]
if not os.path.isdir(outdir):
    os.makedirs(outdir)

monitor = ConsoleTaskMonitor()
decomp = DecompInterface()
decomp.openProgram(currentProgram)

fm = currentProgram.getFunctionManager()
funcs = list(fm.getFunctions(True))

cpath = os.path.join(outdir, "decompiled.c")
lpath = os.path.join(outdir, "functions.txt")
fc = open(cpath, "w")
fl = open(lpath, "w")
ok = 0
fail = 0
for f in funcs:
    name = f.getName()
    ep = str(f.getEntryPoint())
    fl.write("%s\t%s\n" % (ep, name))
    try:
        res = decomp.decompileFunction(f, 60, monitor)
        if res is not None and res.decompileCompleted():
            fc.write("// ===== %s  @ %s =====\n" % (name, ep))
            fc.write(res.getDecompiledFunction().getC())
            fc.write("\n\n")
            ok += 1
        else:
            fc.write("// [decompile failed] %s @ %s\n\n" % (name, ep))
            fail += 1
    except Exception as e:
        fc.write("// [exception] %s : %s\n\n" % (name, str(e)))
        fail += 1
    if ok > 0 and ok % 200 == 0:
        println("REBox progress: %d functions decompiled..." % ok)

fc.close()
fl.close()

info = open(os.path.join(outdir, "info.txt"), "w")
info.write("Program: %s\n" % currentProgram.getName())
info.write("Language: %s\n" % currentProgram.getLanguageID())
info.write("Compiler: %s\n" % currentProgram.getCompilerSpec().getCompilerSpecID())
info.write("Image base: %s\n" % currentProgram.getImageBase())
info.write("Functions total: %d, decompiled: %d, failed: %d\n" % (len(funcs), ok, fail))
info.close()
decomp.dispose()
println("REBOX_EXPORT_DONE functions=%d ok=%d fail=%d" % (len(funcs), ok, fail))
