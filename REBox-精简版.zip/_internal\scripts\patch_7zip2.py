﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "core", "toolmgr.py")
t = io.open(P, "r", encoding="utf-8").read()

old = '''def install_7zip(task):
    """7-Zip 便携版：用官方 7zr.exe 解包安装包提取 7z.exe（免安装、免管理员权限，避免 WinError 740）。"""
    import subprocess
    dest = os.path.join(TOOLS_DIR, "7zip")
    if os.path.isfile(os.path.join(dest, "7z.exe")):
        task.log("7-Zip 已就绪，跳过下载。", "ok")
        return True
    os.makedirs(dest, exist_ok=True)
    zr = os.path.join(dest, "7zr.exe")
    exe_path = os.path.join(dest, "7z2201-x64.exe")
    task.log("下载 7-Zip 便携组件（官方 7zr.exe）……", "info")
    try:
        got = _download_one("https://www.7-zip.org/a/7zr.exe", zr, task, 512 * 1024)
        if got < 300 * 1024:
            raise RuntimeError("7zr.exe 下载体积异常")
        task.log("下载 7-Zip 安装包（解包用，约 2MB）……", "info")
        got2 = _download_one("https://www.7-zip.org/a/7z2201-x64.exe", exe_path, task, 2 * 1048576)
        if got2 < 1 * 1048576:
            raise RuntimeError("安装包下载体积异常")
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError("7-Zip 下载失败：%s" % e)
    task.log("解包便携版（免安装、免管理员权限）……", "info")
    try:
        p = subprocess.run([zr, "x", exe_path, "-o" + dest, "-y"],
                           creationflags=0x08000000, timeout=120,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if p.returncode != 0:
            raise RuntimeError("解包失败（exit %d）" % p.returncode)
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError("解包失败：%s" % e)
    finally:
        try:
            os.remove(exe_path)
        except Exception:
            pass
    if not os.path.isfile(os.path.join(dest, "7z.exe")):
        raise RuntimeError("7-Zip 解包失败：未找到 7z.exe")
    task.log("7-Zip 便携版就绪：%s" % os.path.join(dest, "7z.exe"), "ok")
    return True'''

new = '''def _fetch_retry(url, dest, task, min_bytes, tries=4, hint=0):
    """带重试的下载：网络抖动（连接重置/超时）时自动退避重试。"""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    for i in range(tries):
        if task.cancelled():
            return False
        try:
            got = _download_one(url, dest, task, hint)
            if got >= min_bytes:
                return True
            task.log("下载体积异常（%d 字节），重试……" % got, "warn")
        except Exception as e:
            task.log("第 %d 次尝试失败：%s" % (i + 1, str(e)[:100]), "warn")
        time.sleep(1 + i)
    return False


def install_7zip(task):
    """7-Zip 便携版，多源获取：NuGet 命令行包（zip 直接解出 7z.exe）优先，
    官方安装包解包兜底。全程免安装、免管理员权限（避免 WinError 740）。"""
    import subprocess
    dest = os.path.join(TOOLS_DIR, "7zip")
    if os.path.isfile(os.path.join(dest, "7z.exe")):
        task.log("7-Zip 已就绪，跳过下载。", "ok")
        return True
    os.makedirs(dest, exist_ok=True)

    # 源 1：NuGet 7-Zip.CommandLine（nupkg = zip，内含 tools/x64/7z.exe）
    task.log("尝试源 1/2：NuGet 7-Zip 命令行版……", "info")
    idx = os.path.join(CACHE_DIR, "7zcl-index.json")
    ver = None
    if _fetch_retry("https://api.nuget.org/v3-flatcontainer/7-zip.commandline/index.json",
                    idx, task, 40, 4, 1024):
        try:
            with io.open(idx, "r", encoding="utf-8") as f:
                ver = json.load(f)["versions"][-1]
        except Exception:
            ver = None
    if ver:
        pkg = os.path.join(dest, "7zcl.nupkg")
        if _fetch_retry("https://api.nuget.org/v3-flatcontainer/7-zip.commandline/%s/7-zip.commandline.%s.nupkg" % (ver, ver),
                        pkg, task, 400 * 1024, 5, 2 * 1048576):
            try:
                if zipfile.is_zipfile(pkg):
                    z = zipfile.ZipFile(pkg)
                    cand = [n for n in z.namelist() if n.lower().endswith("7z.exe")]
                    if cand:
                        n = cand[-1]
                        z.extract(n, dest)
                        src = os.path.join(dest, *n.split("/"))
                        shutil.copy2(src, os.path.join(dest, "7z.exe"))
                        task.log("NuGet 源成功：%s" % n, "ok")
            except Exception as e:
                task.log("NuGet 解包失败：%s" % str(e)[:100], "warn")
            finally:
                try:
                    os.remove(pkg)
                except Exception:
                    pass

    # 源 2：官方安装包，用 7zr.exe 解包
    if not os.path.isfile(os.path.join(dest, "7z.exe")):
        task.log("源 1 不可用，尝试源 2/2：官方安装包解包……", "info")
        zr = os.path.join(dest, "7zr.exe")
        if _fetch_retry("https://www.7-zip.org/a/7zr.exe", zr, task, 300 * 1024, 4, 512 * 1024):
            exe_path = os.path.join(dest, "7z2201-x64.exe")
            if _fetch_retry("https://www.7-zip.org/a/7z2201-x64.exe", exe_path, task,
                            1 * 1048576, 5, 2 * 1048576):
                try:
                    p = subprocess.run([zr, "x", exe_path, "-o" + dest, "-y"],
                                       creationflags=0x08000000, timeout=120,
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    if p.returncode != 0:
                        task.log("官方包解包失败（exit %d）" % p.returncode, "warn")
                except Exception as e:
                    task.log("官方包解包异常：%s" % str(e)[:100], "warn")
                finally:
                    try:
                        os.remove(exe_path)
                    except Exception:
                        pass

    if not os.path.isfile(os.path.join(dest, "7z.exe")):
        raise RuntimeError("7-Zip 获取失败：两个源均未成功（网络受限），请稍后重试，或手动将 7z.exe 放入 tools\\\\7zip\\")
    task.log("7-Zip 便携版就绪：%s" % os.path.join(dest, "7z.exe"), "ok")
    return True'''

assert old in t, "install_7zip anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("toolmgr patched v2")
