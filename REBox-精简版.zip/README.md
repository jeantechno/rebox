﻿# REBox · 逆向打包工具箱

> 版本 1.0.0 ｜ 创作者：解域江安 ｜ QQ交流群：1124717353 ｜ 抖音：解域江安 ｜ 快手：解安

一款带液态玻璃界面的**反编译 + 一键打包**桌面工具箱，覆盖 EXE / APK / HAP（鸿蒙）/ Linux / 苹果 五大平台。

## 快速开始

1. 双击 `启动REBox.bat`（或直接运行 `REBox.exe`）；
2. 首次启动请阅读并勾选**合规承诺**（仅可用于自有、已授权或学习研究用途）；
3. 左侧选择功能模块，按界面提示选择文件并操作。

## 功能总览

| 模块 | 反编译 | 打包 |
| --- | --- | --- |
| **EXE** | PE 识别 → PyInstaller 归档提取（pyc）→ 反编译 Python 源码 | 一键 PyInstaller 打包 |
| **APK** | apktool 解包 → 资源/源码反编译 | 回编译 + zipalign + 签名，产出可安装 APK |
| **HAP（鸿蒙）** | 解包 HAP + 内部 DEX 反编译（jadx）| 重新归档打包（真机签名需 hap-sign-tool）|
| **Linux** | deb/rpm/AppImage/tar.gz 解包 + ELF 分析（可选 Ghidra）| tar.gz / deb 结构 + 启动脚本 |
| **苹果** | ipa/dmg/app/pkg 解包 + Mach-O 分析（可选 Ghidra）| .app + zip + 部署脚本 |

- 工具中心：一键检测/下载所需工具链（apktool、jadx、pyinstaller、Ghidra、dnSpy、7-Zip 等）
- 个性化：4 套渐变主题 + 背景图 + 高斯模糊强度自定义
- 环境检测：Java / Python / APK / EXE / HAP / Linux·苹果 工具链状态一目了然

## 目录说明（随包）

```
REBox/
├─ REBox.exe           主程序（绿色版，无需安装）
├─ 启动REBox.bat       双击启动
├─ tools/              工具链（apktool.jar、jadx、uber-apk-signer.jar、7z 等）
├─ workspace/          工作目录（样本、输出结果）
└─ config.json         个人配置（自动生成）
```

## 常见问题

- **首次运行被杀毒软件拦截**：绿色软件未签名属正常现象，选择"仍要运行"即可（工具均为开源社区软件）。
- **反编译/打包较慢**：APK 签名、Ghidra 分析等为正常耗时；下载 Ghidra 约 400MB，需耐心。
- **HAP 真机安装**：请在 DevEco Studio 中完成正式签名后再安装到设备。

## 合规声明

本工具仅供**学习研究、自有软件、已获授权软件**使用。请遵守目标软件许可协议及当地法律法规，请勿用于破解商业软件或侵权用途。
