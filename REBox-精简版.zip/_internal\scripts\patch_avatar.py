﻿# -*- coding: utf-8 -*-
import io, os, base64
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"

img = r"C:\Users\technology\Pictures\Screenshots\屏幕截图 2026-07-30 221244.png"
with open(img, "rb") as f:
    b64 = base64.b64encode(f.read()).decode("ascii")
data = "data:image/png;base64," + b64
print("data url length:", len(data))

P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()
old = """.author-avatar { width: 44px; height: 44px; border-radius: 14px; flex: 0 0 44px; display: grid; place-items: center;
  font-size: 19px; font-weight: 800; color: #fff; background: linear-gradient(135deg, var(--teal), var(--cyan));
  box-shadow: 0 6px 18px rgba(56, 210, 190, .35); }"""
new = """.author-avatar { width: 44px; height: 44px; border-radius: 14px; flex: 0 0 44px; display: grid; place-items: center;
  font-size: 0; color: transparent;
  background-image: url("DATA_HERE");
  background-size: cover; background-position: center;
  border: 1px solid rgba(255,255,255,.14);
  box-shadow: 0 6px 18px rgba(0,0,0,.35); }"""
assert old in t, "author-avatar anchor missing"
new = new.replace("DATA_HERE", data, 1)
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("css patched, total bytes:", len(t))
