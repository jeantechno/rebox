# -*- coding: utf-8 -*-
"""一次性补丁：app.css 追加作者卡 / 滑块 / 侧边栏滚动样式。"""
import io, os

D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "web", "css", "app.css")
t = io.open(P, "r", encoding="utf-8").read()

extra = '''
/* ---------------- 创作者卡片 ---------------- */
.author-card { display: flex; align-items: center; gap: 14px; padding: 15px 18px; margin-top: 16px; border-radius: 18px; }
.author-avatar { width: 44px; height: 44px; border-radius: 14px; flex: 0 0 44px; display: grid; place-items: center;
  font-size: 19px; font-weight: 800; color: #fff; background: linear-gradient(135deg, var(--teal), var(--cyan));
  box-shadow: 0 6px 18px rgba(56, 210, 190, .35); }
.author-info { flex: 1; min-width: 0; }
.author-info b { font-size: 14px; color: #e7f2ff; display: block; }
.author-info span { font-size: 12px; color: var(--text-3); }
.author-links { display: flex; flex-wrap: wrap; gap: 7px; justify-content: flex-end; }
.author-card.glass-inner { margin-top: 10px; border-radius: 15px; }

/* ---------------- 外观设置 ---------------- */
.slider { -webkit-appearance: none; appearance: none; width: 100%; height: 7px; border-radius: 99px; outline: none;
  background: linear-gradient(90deg, rgba(56,210,190,.55), rgba(60,170,255,.55)); margin: 6px 0 2px; cursor: pointer; }
.slider::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 20px; height: 20px; border-radius: 50%;
  background: #fff; border: none; box-shadow: 0 2px 10px rgba(0,0,0,.4), 0 0 0 4px rgba(56,210,190,.25);
  transition: transform .15s var(--ease); }
.slider::-webkit-slider-thumb:hover { transform: scale(1.12); }
.slider-val { display: inline-block; min-width: 46px; text-align: center; font-size: 12.5px; font-weight: 700;
  color: var(--teal); background: rgba(56,210,190,.12); border-radius: 99px; padding: 2px 9px; margin-left: 6px; }

/* ---------------- 侧边栏长导航滚动 ---------------- */
.sidebar nav { flex: 1; overflow-y: auto; min-height: 0; scrollbar-width: thin; scrollbar-color: rgba(255,255,255,.18) transparent; }
.sidebar nav::-webkit-scrollbar { width: 5px; }
.sidebar nav::-webkit-scrollbar-thumb { background: rgba(255,255,255,.16); border-radius: 99px; }
.sidebar nav::-webkit-scrollbar-track { background: transparent; }
'''
t = t + "\n" + extra
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("app.css patched, tail =", len(t), "chars")
