# -*- coding: utf-8 -*-
"""一次性补丁：toolmgr.py 增加 7-Zip 静默安装。"""
import io, os

D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "core", "toolmgr.py")
t = io.open(P, "r", encoding="utf-8").read()

# 1) TOOLS 注册 7zip
old_tools = '''    "ghidra": {
        "repo": "NationalSecurityAgency/ghidra",
        "asset": r"^ghidra_[\\d.]+_PUBLIC_\\d+\\.zip$",
        "mode": "smart",
        "destdir": os.path.join(TOOLS_DIR, "ghidra"),
        "marker": os.path.join("support", "analyzeHeadless.bat"),
        "min_mb": 300,
        "label": "Ghidra（原生程序反编译，约 400MB）",
    },
}'''
new_tools = '''    "ghidra": {
        "repo": "NationalSecurityAgency/ghidra",
        "asset": r"^ghidra_[\\d.]+_PUBLIC_\\d+\\.zip$",
        "mode": "smart",
        "destdir": os.path.join(TOOLS_DIR, "ghidra"),
        "marker": os.path.join("support", "analyzeHeadless.bat"),
        "min_mb": 300,
        "label": "Ghidra（原生程序反编译，约 400MB）",
    },
    "7zip": {
        "mode": "nsis",
        "label": "7-Zip（deb/rpm/dmg/AppImage 解包）",
    },
}'''
assert old_tools in t, "tools anchor missing"
t = t.replace(old_tools, new_tools, 1)

# 2) install_tool 增加 7zip 分支
old_inst = '''def install_tool(name, task):
    spec = TOOLS[name]'''
new_inst = '''def install_7zip(task):
    """7-Zip 官方安装包静默安装到 tools\\\\7zip（NSIS /S /D=）。"""
    url = "https://www.7-zip.org/a/7z2201-x64.exe"
    exe_path = os.path.join(CACHE_DIR, "7z2201-x64.exe")
    os.makedirs(CACHE_DIR, exist_ok=True)
    dest = os.path.join(TOOLS_DIR, "7zip")
    if os.path.isfile(os.path.join(dest, "7z.exe")):
        task.log("7-Zip 已安装，跳过下载。", "ok")
        return True
    task.log("下载 7-Zip 官方安装包（约 2MB）……", "info")
    try:
        got = _download_one(url, exe_path, task, 2 * 1048576)
        if got < 1 * 1048576:
            raise RuntimeError("下载体积异常（%.1fMB）" % (got / 1048576))
    except Exception as e:
        raise RuntimeError("7-Zip 下载失败：%s" % e)
    os.makedirs(dest, exist_ok=True)
    task.log("静默安装到 %s……" % dest, "info")
    import subprocess
    p = subprocess.run([exe_path, "/S", "/D=" + dest],
                       creationflags=0x08000000, timeout=180)
    try:
        os.remove(exe_path)
    except Exception:
        pass
    if not os.path.isfile(os.path.join(dest, "7z.exe")):
        raise RuntimeError("7-Zip 安装失败：未找到 7z.exe（安装包可能被安全软件拦截）")
    task.log("7-Zip 安装完成：%s" % os.path.join(dest, "7z.exe"), "ok")
    return True


def install_tool(name, task):
    if name == "7zip":
        return install_7zip(task)
    spec = TOOLS[name]'''
assert old_inst in t, "install anchor missing"
t = t.replace(old_inst, new_inst, 1)

io.open(P, "w", encoding="utf-8", newline="").write(t)
print("toolmgr.py patched")
