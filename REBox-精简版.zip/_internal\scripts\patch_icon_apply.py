﻿# -*- coding: utf-8 -*-
import io, os
D = r"C:\Users\technology\Doubao\chats\2026-09-19\new-chat-1\REBox"
P = os.path.join(D, "app", "main.py")
t = io.open(P, "r", encoding="utf-8").read()

old = '''def apply_dwm(title):
    """Win11 窗口圆角 + 深色边框；低版本系统静默忽略。"""
    try:
        user32 = ctypes.windll.user32
        dwm = ctypes.windll.dwmapi
        hwnd = user32.FindWindowW(None, title)
        if not hwnd:
            return
        pref = ctypes.c_int(2)  # DWMWA_WINDOW_CORNER_PREFERENCE = DWMWCP_ROUND
        dwm.DwmSetWindowAttribute(hwnd, 33, ctypes.byref(pref), ctypes.sizeof(pref))
        dark = ctypes.c_int(1)  # DWMWA_USE_IMMERSIVE_DARK_MODE
        dwm.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark), ctypes.sizeof(dark))
    except Exception:
        pass'''

new = '''def apply_dwm(title):
    """Win11 窗口圆角 + 深色边框；低版本系统静默忽略。"""
    try:
        user32 = ctypes.windll.user32
        dwm = ctypes.windll.dwmapi
        hwnd = user32.FindWindowW(None, title)
        if not hwnd:
            return
        pref = ctypes.c_int(2)  # DWMWA_WINDOW_CORNER_PREFERENCE = DWMWCP_ROUND
        dwm.DwmSetWindowAttribute(hwnd, 33, ctypes.byref(pref), ctypes.sizeof(pref))
        dark = ctypes.c_int(1)  # DWMWA_USE_IMMERSIVE_DARK_MODE
        dwm.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark), ctypes.sizeof(dark))
    except Exception:
        pass


def apply_icon(path):
    """通过 pythonnet 给窗口设置应用图标（任务栏 / 窗口标题栏）。"""
    if not path or not os.path.isfile(path):
        return
    try:
        import clr  # noqa: F401
        from System.Drawing import Icon
        w = webview.active_window()
        f = w.native
        f.Icon = Icon.FromFile(path)
        f.ShowIcon = True
    except Exception:
        pass'''

assert old in t, "apply_dwm anchor missing"
t = t.replace(old, new, 1)

old = '''    def on_loaded():
        apply_dwm(APP_TITLE)'''
new = '''    def on_loaded():
        apply_dwm(APP_TITLE)
        apply_icon(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "REBox.ico"))'''
assert old in t, "on_loaded anchor missing"
t = t.replace(old, new, 1)
io.open(P, "w", encoding="utf-8", newline="").write(t)
print("main.py ok")
